import express from "express";
import { createServer } from "http";
import { Server } from "socket.io";
import { createServer as createViteServer } from "vite";
import path from "path";
import { fileURLToPath } from "url";

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

async function startServer() {
  const app = express();
  const httpServer = createServer(app);
  const io = new Server(httpServer, {
    cors: {
      origin: "*",
    },
  });

  const PORT = 3000;

  // Mock database for seat locks
  // Key: theaterId-movieId-time-date
  // Value: { seatId: { userId, lockedAt } }
  const seatLocks: Record<string, Record<string, { userId: string, lockedAt: number }>> = {};
  const confirmedBookings: Record<string, string[]> = {};

  io.on("connection", (socket) => {
    console.log("User connected:", socket.id);

    socket.on("join-room", (room) => {
      socket.join(room);
      // Send current locks and bookings for this room
      socket.emit("room-data", {
        locks: seatLocks[room] || {},
        bookings: confirmedBookings[room] || [],
      });
    });

    socket.on("toggle-seat", ({ room, seatId, userId }) => {
      if (!seatLocks[room]) seatLocks[room] = {};
      
      const currentLock = seatLocks[room][seatId];
      
      if (currentLock) {
        if (currentLock.userId === userId) {
          // Unlock if it's the same user
          delete seatLocks[room][seatId];
          io.to(room).emit("seat-updated", { seatId, lock: null });
        } else {
          // Already locked by someone else
          socket.emit("error", "Ghế này đã được người khác chọn!");
        }
      } else {
        // Lock the seat
        seatLocks[room][seatId] = { userId, lockedAt: Date.now() };
        io.to(room).emit("seat-updated", { seatId, lock: { userId, lockedAt: Date.now() } });
      }
    });

    socket.on("confirm-booking", ({ room, seatIds, userId, email }) => {
      if (!confirmedBookings[room]) confirmedBookings[room] = [];
      
      // Verify all seats are locked by this user
      const allLockedByMe = seatIds.every((id: string) => seatLocks[room]?.[id]?.userId === userId);
      
      if (allLockedByMe) {
        confirmedBookings[room].push(...seatIds);
        // Clear locks
        seatIds.forEach((id: string) => delete seatLocks[room][id]);
        
        io.to(room).emit("booking-confirmed", { seatIds });
        
        // Mock Email Notification
        console.log(`[EMAIL SENT] To: ${email} - Booking confirmed for seats: ${seatIds.join(", ")}`);
      } else {
        socket.emit("error", "Có lỗi xảy ra khi xác nhận đặt vé!");
      }
    });

    socket.on("disconnect", () => {
      // Clean up locks for this user (simplified)
      Object.keys(seatLocks).forEach(room => {
        Object.keys(seatLocks[room]).forEach(seatId => {
          if (seatLocks[room][seatId].userId === socket.id) {
            delete seatLocks[room][seatId];
            io.to(room).emit("seat-updated", { seatId, lock: null });
          }
        });
      });
    });
  });

  // API Routes
  app.use(express.json());
  
  app.get("/api/health", (req, res) => {
    res.json({ status: "ok" });
  });

  // Vite middleware for development
  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    app.use(express.static(path.join(__dirname, "dist")));
    app.get("*", (req, res) => {
      res.sendFile(path.join(__dirname, "dist", "index.html"));
    });
  }

  httpServer.listen(PORT, "0.0.0.0", () => {
    console.log(`Server running on http://localhost:${PORT}`);
  });
}

startServer();
