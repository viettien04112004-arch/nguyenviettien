import { Movie, Theater, Showing, Combo, News } from './types';

export const MOCK_MOVIES: Movie[] = [
  {
    id: '1',
    title: 'Dune: Hành Tinh Cát - Phần Hai',
    image: 'https://picsum.photos/seed/dune/400/600',
    banner: 'https://picsum.photos/seed/dunebanner/1200/600',
    duration: 166,
    genre: ['Hành Động', 'Phiêu Lưu', 'Khoa Học Viễn Tưởng'],
    rating: 8.9,
    ageRating: 'T13',
    releaseDate: '2024-03-01',
    description: 'Paul Atreides hợp lực với Chani và người Fremen khi đang trên con đường trả thù những kẻ âm mưu tiêu diệt gia đình mình.',
    status: 'now-showing',
    trailerUrl: 'https://www.youtube.com/embed/Way9Dexny3w'
  },
  {
    id: '2',
    title: 'Oppenheimer',
    image: 'https://picsum.photos/seed/opp/400/600',
    banner: 'https://picsum.photos/seed/oppbanner/1200/600',
    duration: 180,
    genre: ['Tiểu Sử', 'Chính Kịch', 'Lịch Sử'],
    rating: 8.4,
    ageRating: 'T16',
    releaseDate: '2023-07-21',
    description: 'Câu chuyện về nhà khoa học người Mỹ J. Robert Oppenheimer và vai trò của ông trong việc phát triển bom nguyên tử.',
    status: 'now-showing',
    trailerUrl: 'https://www.youtube.com/embed/uYPbbksJxIg'
  },
  {
    id: '3',
    title: 'Spider-Man: Du Hành Vũ Trụ Nhện',
    image: 'https://picsum.photos/seed/spidey/400/600',
    banner: 'https://picsum.photos/seed/spideybanner/1200/600',
    duration: 140,
    genre: ['Hoạt Hình', 'Hành Động', 'Phiêu Lưu'],
    rating: 9.0,
    ageRating: 'P',
    releaseDate: '2025-06-01',
    description: 'Miles Morales trở lại trong chương tiếp theo của loạt phim Spider-Verse từng đoạt giải Oscar.',
    status: 'coming-soon',
    trailerUrl: ''
  },
  {
    id: '4',
    title: 'Vây Hãm: Kẻ Trừng Phạt',
    image: 'https://picsum.photos/seed/roundup/400/600',
    banner: 'https://picsum.photos/seed/roundupbanner/1200/600',
    duration: 109,
    genre: ['Hành Động', 'Tội Phạm'],
    rating: 8.2,
    ageRating: 'T18',
    releaseDate: '2024-04-26',
    description: 'Thanh tra Ma Seok-do đối đầu với một tổ chức cờ bạc trực tuyến quy mô lớn.',
    status: 'now-showing',
    trailerUrl: ''
  }
];

export const MOCK_THEATERS: Theater[] = [
  { 
    id: 't1', 
    name: 'VTIX Landmark 81', 
    address: 'Vinhomes Central Park, Q. Bình Thạnh, TP. HCM',
    province: 'TP. Hồ Chí Minh',
    group: 'VTIX Premium',
    lat: 10.7947,
    lng: 106.7218
  },
  { 
    id: 't2', 
    name: 'VTIX Hùng Vương Plaza', 
    address: '126 Hùng Vương, Q. 5, TP. HCM',
    province: 'TP. Hồ Chí Minh',
    group: 'VTIX Standard',
    lat: 10.7570,
    lng: 106.6644
  },
  { 
    id: 't3', 
    name: 'VTIX Vincom Bà Triệu', 
    address: '191 Bà Triệu, Q. Hai Bà Trưng, Hà Nội',
    province: 'Hà Nội',
    group: 'VTIX Premium',
    lat: 21.0116,
    lng: 105.8493
  },
  { 
    id: 't4', 
    name: 'VTIX Royal City', 
    address: '72A Nguyễn Trãi, Q. Thanh Xuân, Hà Nội',
    province: 'Hà Nội',
    group: 'VTIX Standard',
    lat: 21.0028,
    lng: 105.8158
  },
  { 
    id: 't5', 
    name: 'VTIX Đà Nẵng Riverside', 
    address: 'Trần Hưng Đạo, Q. Sơn Trà, Đà Nẵng',
    province: 'Đà Nẵng',
    group: 'VTIX Standard',
    lat: 16.0678,
    lng: 108.2288
  }
];

export const MOCK_COMBOS: Combo[] = [
  { id: 'c1', name: 'Combo 1 Người', price: 85000, description: '1 Bắp lớn + 1 Nước ngọt lớn', image: 'https://picsum.photos/seed/popcorn1/200/200' },
  { id: 'c2', name: 'Combo 2 Người', price: 135000, description: '1 Bắp lớn + 2 Nước ngọt lớn', image: 'https://picsum.photos/seed/popcorn2/200/200' },
  { id: 'c3', name: 'Combo Nhóm (3-5 Người)', price: 245000, description: '2 Bắp lớn + 4 Nước ngọt lớn + 1 Snack', image: 'https://picsum.photos/seed/popcorn3/200/200' }
];

export const MOCK_NEWS: News[] = [
  {
    id: 'n1',
    title: 'Ưu đãi Thứ Hai Cuối Tháng',
    summary: 'Giảm giá 50% giá vé cho tất cả các suất chiếu vào ngày Thứ Hai cuối cùng của tháng.',
    image: 'https://picsum.photos/seed/promo1/800/400',
    date: '2024-05-20',
    category: 'Khuyến Mãi'
  },
  {
    id: 'n2',
    title: 'Khai trương cụm rạp mới tại Thủ Đức',
    summary: 'VTIX chính thức có mặt tại Gigamall Thủ Đức với nhiều phần quà hấp dẫn.',
    image: 'https://picsum.photos/seed/promo2/800/400',
    date: '2024-05-15',
    category: 'Sự Kiện'
  }
];
