export interface Movie {
  id: string;
  title: string;
  image: string;
  banner: string;
  duration: number;
  genre: string[];
  rating: number;
  ageRating: string;
  releaseDate: string;
  description: string;
  status: 'now-showing' | 'coming-soon';
  trailerUrl: string;
}

export interface Showing {
  id: string;
  movieId: string;
  theaterId: string;
  roomId: string;
  startTime: string;
  price: number;
}

export interface Theater {
  id: string;
  name: string;
  address: string;
  province: string;
  group: string;
  lat: number;
  lng: number;
}

export interface Room {
  id: string;
  theaterId: string;
  name: string;
  rows: number;
  cols: number;
}

export interface Seat {
  id: string;
  row: string;
  col: number;
  type: 'standard' | 'vip' | 'double';
  status: 'available' | 'booked' | 'selected' | 'broken';
}

export interface Combo {
  id: string;
  name: string;
  price: number;
  description: string;
  image: string;
}

export interface User {
  id: string;
  name: string;
  email: string;
  role: 'user' | 'admin' | 'staff';
  tier: 'Silver' | 'Gold' | 'Diamond';
  points: number;
}

export interface Ticket {
  id: string;
  userId: string;
  showingId: string;
  seats: string[];
  combos: { comboId: string; quantity: number }[];
  totalPrice: number;
  status: 'paid' | 'cancelled' | 'used';
  qrCode: string;
  createdAt: string;
}

export interface News {
  id: string;
  title: string;
  summary: string;
  image: string;
  date: string;
  category: string;
}
