import React, { useState, useEffect } from 'react';
import { 
  Film, 
  Calendar, 
  User, 
  LayoutDashboard, 
  Ticket, 
  Settings, 
  LogOut, 
  Bell, 
  Search,
  Menu,
  X,
  ChevronRight,
  ChevronDown,
  Star,
  Clock,
  MapPin,
  CreditCard,
  QrCode,
  TrendingUp,
  Users,
  Layers,
  Tag,
  Facebook,
  Instagram,
  Armchair,
  Navigation,
  Compass,
  Info,
  Play,
  Share2,
  Heart,
  ChevronLeft,
  Filter,
  CheckCircle2,
  AlertCircle,
  Gift
} from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { io, Socket } from 'socket.io-client';
import { MOCK_MOVIES, MOCK_THEATERS, MOCK_COMBOS, MOCK_NEWS } from './mockData';
import { Movie, User as UserType, Ticket as TicketType, News, Theater } from './types';
import { Chatbot } from './components/Chatbot';
import { clsx, type ClassValue } from 'clsx';
import { twMerge } from 'tailwind-merge';

const socket: Socket = io();

function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs));
}

// --- Components ---

const Navbar = ({ activeTab, setActiveTab, user, onLogout, isAdminView }: any) => {
  const [isScrolled, setIsScrolled] = useState(false);

  useEffect(() => {
    const handleScroll = () => setIsScrolled(window.scrollY > 50);
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  return (
    <nav className={cn(
      "fixed top-0 left-0 right-0 z-50 transition-all duration-500 px-6 py-4 flex items-center justify-between",
      isScrolled || isAdminView ? "glass-dark" : "bg-transparent"
    )}>
      <div className="flex items-center gap-8">
        <div className="flex items-center gap-2 cursor-pointer group" onClick={() => setActiveTab('home')}>
          <div className="w-10 h-10 bg-primary rounded-xl flex items-center justify-center shadow-[0_0_15px_rgba(139,92,246,0.5)] group-hover:scale-110 transition-transform">
            <Film className="text-white" size={24} />
          </div>
          <span className="text-2xl font-black tracking-tighter text-white uppercase italic">VTIX</span>
        </div>

        {!isAdminView && (
          <div className="hidden md:flex items-center gap-8">
            <button onClick={() => setActiveTab('home')} className={cn("text-sm font-bold uppercase tracking-widest transition-all hover:text-primary", activeTab === 'home' ? "text-primary" : "text-white/50")}>Trang Chủ</button>
            <button onClick={() => setActiveTab('movies')} className={cn("text-sm font-bold uppercase tracking-widest transition-all hover:text-primary", activeTab === 'movies' ? "text-primary" : "text-white/50")}>Phim</button>
            <button onClick={() => setActiveTab('showtimes')} className={cn("text-sm font-bold uppercase tracking-widest transition-all hover:text-primary", activeTab === 'showtimes' ? "text-primary" : "text-white/50")}>Lịch Chiếu</button>
            <button onClick={() => setActiveTab('promotions')} className={cn("text-sm font-bold uppercase tracking-widest transition-all hover:text-primary", activeTab === 'promotions' ? "text-primary" : "text-white/50")}>Khuyến Mãi</button>
          </div>
        )}
      </div>

      <div className="flex items-center gap-4">
        {user ? (
          <div className="flex items-center gap-4">
            <button className="p-2 text-white/50 hover:text-primary transition-colors relative">
              <Bell size={20} />
              <span className="absolute top-1.5 right-1.5 w-2 h-2 bg-secondary rounded-full shadow-[0_0_8px_rgba(244,114,182,0.8)]"></span>
            </button>
            <div className="flex items-center gap-3 pl-4 border-l border-white/10">
              <button 
                onClick={() => setActiveTab('profile')}
                className="flex items-center gap-3 text-left group"
              >
                <div className="text-right hidden sm:block">
                  <p className="text-xs font-bold text-white group-hover:text-primary transition-colors">{user.name}</p>
                  <p className="text-[10px] text-white/40 uppercase tracking-widest">{user.tier} Member</p>
                </div>
                <div className="w-10 h-10 rounded-full bg-primary/20 border border-primary/30 flex items-center justify-center text-primary font-bold group-hover:bg-primary group-hover:text-white transition-all">
                  {user.name[0]}
                </div>
              </button>
              <button onClick={onLogout} className="p-2 text-white/30 hover:text-red-500 transition-colors" title="Đăng xuất">
                <LogOut size={18} />
              </button>
            </div>
          </div>
        ) : (
          <div className="flex items-center gap-4">
            <button onClick={() => setActiveTab('login')} className="text-sm font-bold uppercase tracking-widest text-white/50 hover:text-white transition-colors">Đăng Nhập</button>
            <button onClick={() => setActiveTab('register')} className="px-6 py-2.5 bg-primary text-white text-sm font-bold uppercase tracking-widest rounded-xl shadow-[0_0_15px_rgba(139,92,246,0.3)] hover:scale-105 transition-all">Đăng Ký</button>
          </div>
        )}
      </div>
    </nav>
  );
};

// --- Client Side Views ---

const HomeView = ({ onSelectMovie }: { onSelectMovie: (m: Movie) => void }) => {
  const [filter, setFilter] = useState<'now-showing' | 'coming-soon'>('now-showing');
  const [searchQuery, setSearchQuery] = useState('');

  const filteredMovies = MOCK_MOVIES.filter(m => 
    m.status === filter && 
    (m.title.toLowerCase().includes(searchQuery.toLowerCase()) || 
     m.genre.some(g => g.toLowerCase().includes(searchQuery.toLowerCase())))
  );

  return (
    <div className="relative min-h-screen bg-bg-dark text-white pt-24 pb-20 px-6">
      {/* Hero Section */}
      <section className="relative h-[75vh] rounded-[40px] overflow-hidden mb-16 shadow-2xl">
        <img 
          src={MOCK_MOVIES[0].banner} 
          className="w-full h-full object-cover"
          alt="Hero"
        />
        <div className="absolute inset-0 bg-gradient-to-r from-bg-dark via-bg-dark/40 to-transparent" />
        <div className="absolute bottom-16 left-16 max-w-2xl">
          <div className="flex items-center gap-3 mb-6">
            <span className="px-4 py-1.5 bg-primary text-white text-[10px] font-black rounded-lg uppercase tracking-[0.2em] shadow-[0_0_20px_rgba(139,92,246,0.5)]">Đang Hot</span>
            <span className="text-sm text-white/60 font-bold tracking-wide">{MOCK_MOVIES[0].genre.join(' • ')} • 2h 46m</span>
          </div>
          <h1 className="text-7xl font-black mb-8 tracking-tighter leading-[0.9] uppercase italic">{MOCK_MOVIES[0].title}</h1>
          <div className="flex items-center gap-6">
            <button 
              onClick={() => onSelectMovie(MOCK_MOVIES[0])}
              className="px-10 py-4 btn-gradient text-white font-black rounded-2xl flex items-center gap-3 uppercase tracking-widest text-sm"
            >
              Đặt Vé Ngay <ChevronRight size={20} />
            </button>
            <button className="px-10 py-4 glass text-white font-black rounded-2xl border border-white/10 hover:bg-white/10 transition-all uppercase tracking-widest text-sm">
              Xem Trailer
            </button>
          </div>
        </div>
      </section>

      {/* Movie Grid */}
      <section className="mb-24">
        <div className="flex flex-col md:flex-row md:items-center justify-between mb-16 gap-8">
          <div className="flex flex-col gap-3">
            <h2 className="text-4xl font-black tracking-tighter uppercase italic">Danh Sách Phim</h2>
            <div className="w-24 h-1.5 bg-primary rounded-full shadow-[0_0_10px_rgba(139,92,246,0.5)]" />
          </div>
          
          <div className="flex flex-col md:flex-row items-center gap-6">
            <div className="relative w-full md:w-80">
              <input 
                type="text" 
                placeholder="Tìm tên phim, thể loại..." 
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="w-full bg-white/5 border border-white/10 rounded-2xl px-8 py-3 text-sm focus:outline-none focus:border-primary transition-all placeholder:text-white/20"
              />
              <Search className="absolute right-6 top-1/2 -translate-y-1/2 text-white/20" size={18} />
            </div>

            <div className="flex p-1.5 bg-white/5 rounded-2xl border border-white/5 w-full md:w-auto">
              <button 
                onClick={() => setFilter('now-showing')}
                className={cn(
                  "flex-1 md:flex-none px-8 py-2.5 rounded-xl text-xs font-black uppercase tracking-widest transition-all",
                  filter === 'now-showing' ? "bg-primary text-white shadow-[0_0_20px_rgba(139,92,246,0.4)]" : "text-white/30 hover:text-white"
                )}
              >
                Đang Chiếu
              </button>
              <button 
                onClick={() => setFilter('coming-soon')}
                className={cn(
                  "flex-1 md:flex-none px-8 py-2.5 rounded-xl text-xs font-black uppercase tracking-widest transition-all",
                  filter === 'coming-soon' ? "bg-primary text-white shadow-[0_0_20px_rgba(139,92,246,0.4)]" : "text-white/30 hover:text-white"
                )}
              >
                Sắp Chiếu
              </button>
            </div>
          </div>
        </div>
        
        <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-5 gap-10">
          {filteredMovies.length > 0 ? filteredMovies.map((movie) => (
            <motion.div 
              key={movie.id}
              layout
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              whileHover={{ y: -15 }}
              className="group cursor-pointer relative"
              onClick={() => onSelectMovie(movie)}
            >
              <div className="relative aspect-[2/3] rounded-[32px] overflow-hidden mb-6 border border-white/5 shadow-2xl bg-white/5">
                <img 
                  src={movie.image} 
                  className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-110" 
                  alt={movie.title} 
                />
                
                {/* Status Badge */}
                <div className={cn(
                  "absolute top-5 left-5 px-4 py-1.5 rounded-lg text-[10px] font-black uppercase tracking-widest shadow-xl z-10",
                  movie.status === 'now-showing' ? "bg-primary text-white" : "bg-accent text-black"
                )}>
                  {movie.status === 'now-showing' ? 'Đang Chiếu' : 'Sắp Chiếu'}
                </div>

                <div className="absolute top-5 right-5 px-3 py-1.5 bg-black/60 backdrop-blur-md rounded-lg text-[10px] font-black border border-white/10 z-10">
                  {movie.ageRating}
                </div>

                {/* Hover Info Overlay */}
                <div className="absolute inset-0 bg-primary/40 backdrop-blur-sm flex flex-col items-center justify-center p-8 opacity-0 group-hover:opacity-100 transition-all duration-500">
                  <div className="text-center transform translate-y-8 group-hover:translate-y-0 transition-transform duration-500">
                    <p className="text-xs font-black text-white uppercase tracking-[0.2em] mb-3">{movie.genre.join(', ')}</p>
                    <p className="text-sm text-white/90 font-medium line-clamp-3 mb-8 leading-relaxed">{movie.description}</p>
                    <button className="px-8 py-3.5 bg-white text-black rounded-2xl flex items-center gap-3 font-black text-xs uppercase tracking-widest transition-all shadow-2xl hover:scale-105">
                      <Ticket size={18} />
                      Mua vé nhanh
                    </button>
                  </div>
                </div>
              </div>
              <h3 className="font-black text-xl mb-2 line-clamp-1 group-hover:text-primary transition-colors uppercase italic tracking-tighter">{movie.title}</h3>
              <div className="flex items-center gap-4 text-xs text-white/40 font-bold uppercase tracking-widest">
                <span className="flex items-center gap-1.5 text-primary"><Star size={14} className="fill-primary" /> {movie.rating}</span>
                <span className="w-1.5 h-1.5 bg-white/10 rounded-full" />
                <span>{movie.duration} phút</span>
              </div>
            </motion.div>
          )) : (
            <div className="col-span-full text-center py-32 border-2 border-dashed border-white/5 rounded-[40px]">
              <p className="text-white/10 uppercase tracking-[0.3em] font-black text-lg">Không tìm thấy phim phù hợp</p>
            </div>
          )}
        </div>
      </section>

      {/* News Section */}
      <section className="mb-24">
        <div className="flex items-center justify-between mb-16">
          <div className="flex flex-col gap-3">
            <h2 className="text-4xl font-black tracking-tighter uppercase italic">Tin Tức & Ưu Đãi</h2>
            <div className="w-24 h-1.5 bg-secondary rounded-full shadow-[0_0_10px_rgba(244,114,182,0.5)]" />
          </div>
          <button className="text-xs font-black uppercase tracking-[0.2em] text-white/30 hover:text-secondary transition-colors">Xem tất cả</button>
        </div>
        <div className="grid md:grid-cols-2 gap-10">
          {MOCK_NEWS.map((news) => (
            <div key={news.id} className="group flex gap-8 p-8 bg-white/5 rounded-[32px] border border-white/5 hover:border-secondary/30 transition-all cursor-pointer">
              <div className="w-48 h-48 flex-shrink-0 rounded-2xl overflow-hidden shadow-2xl">
                <img src={news.image} className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-700" alt={news.title} />
              </div>
              <div className="flex flex-col justify-center">
                <span className="text-[10px] font-black uppercase tracking-[0.2em] text-secondary mb-3">{news.category}</span>
                <h3 className="text-2xl font-black mb-4 group-hover:text-secondary transition-colors tracking-tight leading-tight">{news.title}</h3>
                <p className="text-sm text-white/40 font-medium line-clamp-2 mb-6 leading-relaxed">{news.summary}</p>
                <div className="flex items-center gap-3 text-[10px] text-white/20 uppercase font-black tracking-widest">
                  <Calendar size={14} /> {new Date(news.date).toLocaleDateString('vi-VN')}
                </div>
              </div>
            </div>
          ))}
        </div>
      </section>
    </div>
  );
};

const MoviesView = ({ onSelectMovie }: { onSelectMovie: (m: Movie) => void }) => {
  const [filter, setFilter] = useState<'now-showing' | 'coming-soon'>('now-showing');
  const [searchQuery, setSearchQuery] = useState('');

  const filteredMovies = MOCK_MOVIES.filter(m => 
    m.status === filter && 
    (m.title.toLowerCase().includes(searchQuery.toLowerCase()) || 
     m.genre.some(g => g.toLowerCase().includes(searchQuery.toLowerCase())))
  );

  return (
    <div className="min-h-screen bg-bg-dark text-white pt-32 pb-20 px-6">
      <div className="max-w-7xl mx-auto">
        <div className="flex flex-col md:flex-row md:items-center justify-between mb-16 gap-8">
          <h2 className="text-5xl font-black tracking-tighter italic uppercase">Tất Cả Phim</h2>
          
          <div className="flex flex-col md:flex-row items-center gap-6">
            <div className="relative w-full md:w-80">
              <input 
                type="text" 
                placeholder="Tìm tên phim, thể loại..." 
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="w-full bg-white/5 border border-white/10 rounded-2xl px-8 py-3 text-sm focus:outline-none focus:border-primary transition-all placeholder:text-white/20"
              />
              <Search className="absolute right-6 top-1/2 -translate-y-1/2 text-white/20" size={18} />
            </div>

            <div className="flex p-1.5 bg-white/5 rounded-2xl border border-white/5 w-full md:w-auto">
              <button 
                onClick={() => setFilter('now-showing')}
                className={cn(
                  "flex-1 md:flex-none px-8 py-2.5 rounded-xl text-xs font-black uppercase tracking-widest transition-all",
                  filter === 'now-showing' ? "bg-primary text-white shadow-[0_0_20px_rgba(139,92,246,0.4)]" : "text-white/30 hover:text-white"
                )}
              >
                Đang Chiếu
              </button>
              <button 
                onClick={() => setFilter('coming-soon')}
                className={cn(
                  "flex-1 md:flex-none px-8 py-2.5 rounded-xl text-xs font-black uppercase tracking-widest transition-all",
                  filter === 'coming-soon' ? "bg-primary text-white shadow-[0_0_20px_rgba(139,92,246,0.4)]" : "text-white/30 hover:text-white"
                )}
              >
                Sắp Chiếu
              </button>
            </div>
          </div>
        </div>
        <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-5 gap-10">
          {filteredMovies.length > 0 ? filteredMovies.map((movie) => (
            <motion.div 
              key={movie.id} 
              whileHover={{ y: -15 }} 
              className="group cursor-pointer relative" 
              onClick={() => onSelectMovie(movie)}
            >
              <div className="relative aspect-[2/3] rounded-[32px] overflow-hidden mb-6 border border-white/5 shadow-2xl bg-white/5">
                <img 
                  src={movie.image} 
                  className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-110" 
                  alt={movie.title} 
                />
                
                <div className="absolute top-5 right-5 px-3 py-1.5 bg-black/60 backdrop-blur-md rounded-lg text-[10px] font-black border border-white/10 z-10">
                  {movie.ageRating}
                </div>
                
                {/* Hover Info Overlay */}
                <div className="absolute inset-0 bg-primary/40 backdrop-blur-sm flex flex-col items-center justify-center p-8 opacity-0 group-hover:opacity-100 transition-all duration-500">
                  <div className="text-center transform translate-y-8 group-hover:translate-y-0 transition-transform duration-500">
                    <p className="text-xs font-black text-white uppercase tracking-[0.2em] mb-3">{movie.genre.join(', ')}</p>
                    <p className="text-sm text-white/90 font-medium line-clamp-3 mb-8 leading-relaxed">{movie.description}</p>
                    <div className="w-14 h-14 bg-white rounded-2xl flex items-center justify-center text-black shadow-2xl mx-auto hover:scale-110 transition-transform">
                      <Ticket size={28} />
                    </div>
                  </div>
                </div>
              </div>
              <h3 className="font-black text-xl mb-2 line-clamp-1 group-hover:text-primary transition-colors uppercase italic tracking-tighter">{movie.title}</h3>
              <div className="flex items-center gap-4 text-xs text-white/40 font-bold uppercase tracking-widest">
                <span className="flex items-center gap-1.5 text-primary"><Star size={14} className="fill-primary" /> {movie.rating}</span>
                <span className="w-1.5 h-1.5 bg-white/10 rounded-full" />
                <span>{movie.duration} phút</span>
              </div>
            </motion.div>
          )) : (
            <div className="col-span-full text-center py-32 border-2 border-dashed border-white/5 rounded-[40px]">
              <p className="text-white/10 uppercase tracking-[0.3em] font-black text-lg">Không tìm thấy phim phù hợp</p>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

const ShowtimesView = ({ onSelectMovie }: { onSelectMovie: (m: Movie) => void }) => {
  return (
    <div className="min-h-screen bg-bg-dark text-white pt-32 pb-20 px-6">
      <div className="max-w-7xl mx-auto">
        <h2 className="text-5xl font-black tracking-tighter italic uppercase mb-16">Lịch Chiếu Hệ Thống</h2>
        <div className="space-y-16">
          {MOCK_THEATERS.map(theater => (
            <div key={theater.id} className="p-10 bg-white/5 rounded-[40px] border border-white/5 shadow-2xl">
              <div className="flex items-center gap-6 mb-10">
                <div className="w-16 h-16 bg-primary rounded-2xl flex items-center justify-center text-white shadow-[0_0_20px_rgba(139,92,246,0.5)]"><MapPin size={32} /></div>
                <div>
                  <h3 className="text-3xl font-black uppercase italic tracking-tight">{theater.name}</h3>
                  <p className="text-white/40 text-sm font-bold uppercase tracking-widest">{theater.address}</p>
                </div>
              </div>
              <div className="grid gap-10">
                {MOCK_MOVIES.filter(m => m.status === 'now-showing').map(movie => (
                  <div key={movie.id} className="flex flex-col md:flex-row gap-8 p-8 bg-black/40 rounded-[32px] border border-white/5 hover:border-primary/30 transition-all group">
                    <img src={movie.image} className="w-32 h-48 rounded-2xl object-cover shadow-xl group-hover:scale-105 transition-transform" alt={movie.title} />
                    <div className="flex-1">
                      <h4 className="text-2xl font-black mb-3 uppercase italic tracking-tight group-hover:text-primary transition-colors">{movie.title}</h4>
                      <div className="flex items-center gap-4 text-[10px] text-white/40 font-black uppercase tracking-widest mb-6">
                        <span className="px-3 py-1 bg-white/5 rounded-lg text-primary border border-primary/20">{movie.ageRating}</span>
                        <span>{movie.genre.join(', ')}</span>
                      </div>
                      <div className="flex flex-wrap gap-4">
                        {['10:00', '13:30', '16:00', '19:30', '22:00'].map(time => (
                          <button key={time} onClick={() => onSelectMovie(movie)} className="px-8 py-3 bg-white/5 hover:bg-primary hover:text-white rounded-xl text-sm font-black transition-all border border-white/5 uppercase tracking-widest shadow-lg">
                            {time}
                          </button>
                        ))}
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};

const PromotionsView = () => {
  return (
    <div className="min-h-screen bg-bg-dark text-white pt-32 pb-20 px-6">
      <div className="max-w-7xl mx-auto">
        <h2 className="text-5xl font-black tracking-tighter italic uppercase mb-16">Khuyến Mãi & Ưu Đãi</h2>
        <div className="grid md:grid-cols-2 gap-10">
          {MOCK_NEWS.map(news => (
            <div key={news.id} className="group bg-white/5 rounded-[40px] border border-white/5 overflow-hidden hover:border-primary/30 transition-all shadow-2xl">
              <div className="aspect-video overflow-hidden relative">
                <img src={news.image} className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-700" alt={news.title} />
                <div className="absolute inset-0 bg-gradient-to-t from-bg-dark/80 to-transparent" />
              </div>
              <div className="p-10">
                <span className="text-[10px] font-black uppercase tracking-[0.2em] text-primary mb-3 block">{news.category}</span>
                <h3 className="text-3xl font-black mb-4 group-hover:text-primary transition-colors tracking-tight leading-tight uppercase italic">{news.title}</h3>
                <p className="text-white/40 mb-8 line-clamp-3 font-medium leading-relaxed">{news.summary}</p>
                <div className="flex items-center justify-between">
                  <span className="text-[10px] text-white/20 font-black uppercase tracking-widest">{new Date(news.date).toLocaleDateString('vi-VN')}</span>
                  <button className="px-8 py-3 bg-primary/10 text-primary hover:bg-primary hover:text-white rounded-xl text-xs font-black uppercase tracking-widest transition-all border border-primary/20">
                    Chi tiết
                  </button>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};

const MovieDetailView = ({ movie, onBack, onBook }: { movie: Movie, onBack: () => void, onBook: () => void }) => {
  return (
    <div className="min-h-screen bg-bg-dark text-white">
      <div className="relative h-[60vh]">
        <img src={movie.banner} className="w-full h-full object-cover" alt={movie.title} />
        <div className="absolute inset-0 bg-gradient-to-t from-bg-dark via-bg-dark/60 to-transparent" />
        <button 
          onClick={onBack}
          className="absolute top-32 left-12 p-4 glass rounded-2xl hover:bg-white/10 transition-all z-10"
        >
          <ChevronLeft size={24} />
        </button>
        
        <div className="absolute bottom-16 left-12 right-12 max-w-7xl mx-auto flex flex-col md:flex-row items-end gap-10">
          <div className="w-64 aspect-[2/3] rounded-[32px] overflow-hidden shadow-2xl border-4 border-white/10 hidden md:block transform -translate-y-12">
            <img src={movie.image} className="w-full h-full object-cover" alt={movie.title} />
          </div>
          <div className="flex-1 pb-4">
            <div className="flex items-center gap-4 mb-6">
              <span className="px-4 py-1.5 bg-primary text-white text-[10px] font-black rounded-lg uppercase tracking-widest shadow-lg">{movie.status === 'now-showing' ? 'Đang Chiếu' : 'Sắp Chiếu'}</span>
              <span className="px-4 py-1.5 bg-white/10 backdrop-blur-md text-white text-[10px] font-black rounded-lg uppercase tracking-widest border border-white/10">{movie.ageRating}</span>
              <div className="flex items-center gap-2 text-primary font-black">
                <Star size={18} className="fill-primary" />
                <span className="text-xl">{movie.rating}</span>
              </div>
            </div>
            <h1 className="text-6xl font-black mb-6 uppercase italic tracking-tighter leading-tight">{movie.title}</h1>
            <div className="flex flex-wrap items-center gap-6 text-sm font-bold text-white/60 uppercase tracking-widest">
              <span className="flex items-center gap-2"><Clock size={16} /> {movie.duration} phút</span>
              <span className="w-1.5 h-1.5 bg-white/20 rounded-full" />
              <span>{movie.genre.join(' • ')}</span>
              <span className="w-1.5 h-1.5 bg-white/20 rounded-full" />
              <span>Khởi chiếu: {new Date(movie.releaseDate).toLocaleDateString('vi-VN')}</span>
            </div>
          </div>
          <div className="pb-4">
            <button 
              onClick={onBook}
              className="px-12 py-5 btn-gradient text-white font-black rounded-2xl flex items-center gap-3 uppercase tracking-widest shadow-2xl hover:scale-105"
            >
              <Ticket size={24} />
              Đặt Vé Ngay
            </button>
          </div>
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-12 py-20 grid lg:grid-cols-3 gap-20">
        <div className="lg:col-span-2 space-y-16">
          <section>
            <h3 className="text-2xl font-black uppercase italic tracking-tight mb-8 flex items-center gap-3">
              <div className="w-2 h-8 bg-primary rounded-full" />
              Nội dung phim
            </h3>
            <p className="text-white/50 text-lg leading-relaxed font-medium">{movie.description}</p>
          </section>

          <section>
            <h3 className="text-2xl font-black uppercase italic tracking-tight mb-8 flex items-center gap-3">
              <div className="w-2 h-8 bg-secondary rounded-full" />
              Trailer
            </h3>
            <div className="aspect-video rounded-[40px] overflow-hidden border border-white/10 shadow-2xl bg-black">
              {movie.trailerUrl ? (
                <iframe 
                  src={movie.trailerUrl} 
                  className="w-full h-full" 
                  allowFullScreen 
                  title="Trailer"
                />
              ) : (
                <div className="w-full h-full flex items-center justify-center text-white/20">Trailer không khả dụng</div>
              )}
            </div>
          </section>
        </div>

        <div className="space-y-12">
          <section className="p-10 bg-white/5 rounded-[40px] border border-white/5 shadow-2xl">
            <h3 className="text-xl font-black uppercase italic tracking-tight mb-8">Thông tin chi tiết</h3>
            <div className="space-y-6">
              <div className="flex justify-between items-center py-4 border-b border-white/5">
                <span className="text-white/30 text-xs font-black uppercase tracking-widest">Đạo diễn</span>
                <span className="text-sm font-bold">Denis Villeneuve</span>
              </div>
              <div className="flex justify-between items-center py-4 border-b border-white/5">
                <span className="text-white/30 text-xs font-black uppercase tracking-widest">Diễn viên</span>
                <span className="text-sm font-bold text-right">Timothée Chalamet, Zendaya</span>
              </div>
              <div className="flex justify-between items-center py-4 border-b border-white/5">
                <span className="text-white/30 text-xs font-black uppercase tracking-widest">Ngôn ngữ</span>
                <span className="text-sm font-bold">Tiếng Anh - Phụ đề Tiếng Việt</span>
              </div>
              <div className="flex justify-between items-center py-4">
                <span className="text-white/30 text-xs font-black uppercase tracking-widest">Định dạng</span>
                <span className="text-sm font-bold text-primary">2D, IMAX, 4DX</span>
              </div>
            </div>
          </section>

          <div className="p-10 bg-gradient-to-br from-primary/20 to-secondary/20 rounded-[40px] border border-white/10 shadow-2xl">
            <h4 className="text-lg font-black uppercase italic tracking-tight mb-4">Ưu đãi đặc biệt</h4>
            <p className="text-sm text-white/60 mb-6 leading-relaxed">Nhập mã <span className="text-white font-black">VTIX10</span> để được giảm ngay 10% giá vé cho lần đặt đầu tiên.</p>
            <button className="w-full py-4 bg-white text-black rounded-2xl font-black uppercase tracking-widest text-xs hover:scale-105 transition-all shadow-xl">
              Xem các ưu đãi khác
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};

const deg2rad = (deg: number) => deg * (Math.PI / 180);
const calculateDistance = (lat1: number, lon1: number, lat2: number, lon2: number) => {
  const R = 6371;
  const dLat = deg2rad(lat2 - lat1);
  const dLon = deg2rad(lon2 - lon1);
  const a = Math.sin(dLat / 2) * Math.sin(dLat / 2) + Math.cos(deg2rad(lat1)) * Math.cos(deg2rad(lat2)) * Math.sin(dLon / 2) * Math.sin(dLon / 2);
  const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
  return R * c;
};

const PROVINCES = ['Tất cả tỉnh thành', 'TP. Hồ Chí Minh', 'Hà Nội', 'Đà Nẵng'];
const GROUPS = ['Tất cả cụm rạp', 'VTIX Premium', 'VTIX Standard'];

const BookingFlow = ({ movie, user, onComplete, onCancel }: { movie: Movie, user: UserType | null, onComplete: (code: string, data: any) => void, onCancel: () => void }) => {
  const [step, setStep] = useState(1);
  const [selectedTheater, setSelectedTheater] = useState(MOCK_THEATERS[0]);
  const [selectedTime, setSelectedTime] = useState('19:30');
  const [selectedSeats, setSelectedSeats] = useState<string[]>([]);
  const [selectedCombos, setSelectedCombos] = useState<any[]>([]);
  const [paymentMethod, setPaymentMethod] = useState('Chuyển khoản qua QR');
  const [timeLeft, setTimeLeft] = useState(300);
  const [couponCode, setCouponCode] = useState('');
  const [isCouponApplied, setIsCouponApplied] = useState(false);
  
  const [selectedProvince, setSelectedProvince] = useState(PROVINCES[0]);
  const [selectedGroup, setSelectedGroup] = useState(GROUPS[0]);
  const [selectedDate, setSelectedDate] = useState(new Date().toISOString().split('T')[0]);
  const [userLocation, setUserLocation] = useState<{ lat: number, lng: number } | null>(null);
  const [manualAddress, setManualAddress] = useState('');
  const [isLocating, setIsLocating] = useState(false);

  // Real-time seat state
  const [lockedSeats, setLockedSeats] = useState<Record<string, { userId: string, lockedAt: number }>>({});
  const [bookedSeats, setBookedSeats] = useState<string[]>([]);

  const roomKey = `${selectedTheater.id}-${movie.id}-${selectedTime}-${selectedDate}`;

  useEffect(() => {
    socket.emit("join-room", roomKey);

    socket.on("room-data", ({ locks, bookings }) => {
      setLockedSeats(locks);
      setBookedSeats(bookings);
    });

    socket.on("seat-updated", ({ seatId, lock }) => {
      setLockedSeats(prev => {
        const next = { ...prev };
        if (lock) next[seatId] = lock;
        else delete next[seatId];
        return next;
      });
    });

    socket.on("booking-confirmed", ({ seatIds }) => {
      setBookedSeats(prev => [...prev, ...seatIds]);
      setLockedSeats(prev => {
        const next = { ...prev };
        seatIds.forEach((id: string) => delete next[id]);
        return next;
      });
    });

    socket.on("error", (msg) => alert(msg));

    return () => {
      socket.off("room-data");
      socket.off("seat-updated");
      socket.off("booking-confirmed");
      socket.off("error");
    };
  }, [roomKey]);

  const requestLocation = () => {
    setIsLocating(true);
    if (navigator.geolocation) {
      navigator.geolocation.getCurrentPosition(
        (position) => {
          setUserLocation({
            lat: position.coords.latitude,
            lng: position.coords.longitude
          });
          setIsLocating(false);
        },
        (error) => {
          console.error("Error getting location:", error);
          setIsLocating(false);
          alert("Không thể lấy vị trí của bạn. Vui lòng nhập địa chỉ thủ công.");
        }
      );
    }
  };

  useEffect(() => {
    requestLocation();
  }, []);

  const filteredTheaters = MOCK_THEATERS
    .filter(t => (selectedProvince === 'Tất cả tỉnh thành' || t.province === selectedProvince))
    .filter(t => (selectedGroup === 'Tất cả cụm rạp' || t.group === selectedGroup))
    .map(t => ({
      ...t,
      distance: userLocation ? calculateDistance(userLocation.lat, userLocation.lng, t.lat, t.lng) : null
    }))
    .sort((a, b) => {
      if (a.distance !== null && b.distance !== null) return a.distance - b.distance;
      return 0;
    });

  useEffect(() => {
    if (filteredTheaters.length > 0 && !filteredTheaters.find(t => t.id === selectedTheater.id)) {
      setSelectedTheater(filteredTheaters[0]);
    }
  }, [filteredTheaters, selectedTheater.id]);

  useEffect(() => {
    if (step === 4) {
      const timer = setInterval(() => {
        setTimeLeft((prev) => {
          if (prev <= 1) {
            clearInterval(timer);
            onCancel();
            return 0;
          }
          return prev - 1;
        });
      }, 1000);
      return () => clearInterval(timer);
    }
  }, [step, onCancel]);

  const formatTime = (seconds: number) => {
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${mins}:${secs.toString().padStart(2, '0')}`;
  };

  const toggleSeat = (id: string) => {
    socket.emit("toggle-seat", { room: roomKey, seatId: id, userId: socket.id });
    setSelectedSeats(prev => prev.includes(id) ? prev.filter(s => s !== id) : [...prev, id]);
  };

  const getSeatPrice = (id: string) => {
    const row = id[0];
    if (row === 'H') return 250000; // Sweetbox
    if (['F', 'G'].includes(row)) return 125000; // VIP
    return 95000; // Standard
  };

  const getSeatType = (id: string) => {
    const row = id[0];
    if (row === 'H') return 'Sweetbox';
    if (['F', 'G'].includes(row)) return 'VIP';
    return 'Standard';
  };

  const seatsTotal = selectedSeats.reduce((acc, id) => acc + getSeatPrice(id), 0);
  const combosTotal = selectedCombos.reduce((acc, c) => acc + (c.price * c.qty), 0);
  let totalPrice = seatsTotal + combosTotal;
  if (isCouponApplied) totalPrice *= 0.9; // 10% discount

  const handleConfirm = () => {
    const code = 'CM' + Math.random().toString(36).substring(2, 8).toUpperCase();
    socket.emit("confirm-booking", { 
      room: roomKey, 
      seatIds: selectedSeats, 
      userId: socket.id,
      email: user?.email || 'guest@example.com'
    });
    onComplete(code, {
      movie,
      theater: selectedTheater,
      time: selectedTime,
      date: selectedDate,
      seats: selectedSeats,
      total: totalPrice
    });
  };

  return (
    <div className="min-h-screen bg-bg-dark text-white pt-32 pb-20 px-6">
      {/* Progress Bar */}
      <div className="max-w-4xl mx-auto mb-16">
        <div className="flex items-center justify-between mb-6">
          {['Suất Chiếu', 'Chọn Ghế', 'Bắp Nước', 'Thanh Toán'].map((s, i) => (
            <div key={s} className={cn(
              "text-[10px] font-black uppercase tracking-[0.2em] transition-colors",
              step > i + 1 ? "text-primary" : step === i + 1 ? "text-white" : "text-white/20"
            )}>
              {i + 1}. {s}
            </div>
          ))}
        </div>
        <div className="h-1.5 bg-white/5 rounded-full overflow-hidden">
          <motion.div 
            className="h-full bg-primary shadow-[0_0_15px_rgba(139,92,246,0.5)]"
            initial={{ width: '0%' }}
            animate={{ width: `${(step / 4) * 100}%` }}
          />
        </div>
      </div>

      <div className="max-w-7xl mx-auto grid lg:grid-cols-3 gap-16">
        <div className="lg:col-span-2">
          {step === 1 && (
            <div className="space-y-12">
              {/* Filters */}
              <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                <div>
                  <label className="block text-[10px] font-black uppercase tracking-widest text-white/30 mb-3">Chọn Ngày</label>
                  <div className="relative">
                    <input 
                      type="date" 
                      value={selectedDate}
                      onChange={(e) => setSelectedDate(e.target.value)}
                      className="w-full bg-white/5 border border-white/10 rounded-2xl px-5 py-4 text-sm font-bold focus:outline-none focus:border-primary transition-all appearance-none"
                    />
                    <Calendar className="absolute right-5 top-1/2 -translate-y-1/2 text-white/20 pointer-events-none" size={18} />
                  </div>
                </div>
                <div>
                  <label className="block text-[10px] font-black uppercase tracking-widest text-white/30 mb-3">Tỉnh Thành</label>
                  <select 
                    value={selectedProvince}
                    onChange={(e) => setSelectedProvince(e.target.value)}
                    className="w-full bg-white/5 border border-white/10 rounded-2xl px-5 py-4 text-sm font-bold focus:outline-none focus:border-primary transition-all appearance-none"
                  >
                    {PROVINCES.map(p => <option key={p} value={p} className="bg-bg-dark">{p}</option>)}
                  </select>
                </div>
                <div>
                  <label className="block text-[10px] font-black uppercase tracking-widest text-white/30 mb-3">Cụm Rạp</label>
                  <select 
                    value={selectedGroup}
                    onChange={(e) => setSelectedGroup(e.target.value)}
                    className="w-full bg-white/5 border border-white/10 rounded-2xl px-5 py-4 text-sm font-bold focus:outline-none focus:border-primary transition-all appearance-none"
                  >
                    {GROUPS.map(g => <option key={g} value={g} className="bg-bg-dark">{g}</option>)}
                  </select>
                </div>
              </div>

              <div>
                <div className="flex items-center justify-between mb-8">
                  <h3 className="text-2xl font-black uppercase italic tracking-tight flex items-center gap-3">
                    <div className="w-2 h-8 bg-primary rounded-full" />
                    Chọn Rạp 
                    {userLocation && <span className="text-[10px] font-black uppercase tracking-widest text-primary bg-primary/10 px-3 py-1.5 rounded-full shadow-sm">Đã xác định vị trí</span>}
                  </h3>
                  <div className="flex items-center gap-3">
                    <div className="relative">
                      <input 
                        type="text" 
                        placeholder="Nhập địa chỉ khác..." 
                        value={manualAddress}
                        onChange={(e) => setManualAddress(e.target.value)}
                        className="bg-white/5 border border-white/10 rounded-2xl px-5 py-3 text-xs w-64 focus:outline-none focus:border-primary font-bold"
                      />
                      <MapPin className="absolute right-4 top-1/2 -translate-y-1/2 text-white/20" size={14} />
                    </div>
                    <button 
                      onClick={requestLocation}
                      disabled={isLocating}
                      className="p-3 bg-primary text-white rounded-2xl hover:bg-primary/80 transition-all disabled:opacity-50 shadow-lg shadow-primary/20"
                      title="Tìm rạp quanh đây"
                    >
                      <Navigation size={20} className={cn(isLocating && "animate-pulse")} />
                    </button>
                  </div>
                </div>
                <div className="grid gap-5">
                  {filteredTheaters.length > 0 ? filteredTheaters.map(t => (
                    <button 
                      key={t.id}
                      onClick={() => setSelectedTheater(t)}
                      className={cn(
                        "p-8 rounded-[32px] border text-left transition-all group relative overflow-hidden",
                        selectedTheater.id === t.id ? "bg-primary/10 border-primary shadow-2xl shadow-primary/10" : "bg-white/5 border-white/5 hover:border-white/20"
                      )}
                    >
                      <div className="flex justify-between items-start relative z-10">
                        <div>
                          <p className="font-black text-xl uppercase italic tracking-tight mb-2 group-hover:text-primary transition-colors">{t.name}</p>
                          <p className="text-sm text-white/40 flex items-center gap-2 font-medium"><MapPin size={16} className="text-primary" /> {t.address}</p>
                          <div className="flex gap-3 mt-4">
                            <span className="text-[10px] font-black uppercase tracking-widest bg-white/5 px-3 py-1.5 rounded-lg text-white/30 border border-white/5">{t.group}</span>
                            <span className="text-[10px] font-black uppercase tracking-widest bg-white/5 px-3 py-1.5 rounded-lg text-white/30 border border-white/5">{t.province}</span>
                          </div>
                        </div>
                        {t.distance !== null && (
                          <div className="text-right">
                            <p className="text-primary font-black text-lg tracking-tighter">{t.distance.toFixed(1)} km</p>
                            <p className="text-[10px] text-white/20 font-black uppercase tracking-widest">Khoảng cách</p>
                          </div>
                        )}
                      </div>
                      {selectedTheater.id === t.id && (
                        <div className="absolute top-0 right-0 w-32 h-32 bg-primary/10 blur-[60px] rounded-full -mr-16 -mt-16" />
                      )}
                    </button>
                  )) : (
                    <div className="p-20 text-center bg-white/5 rounded-[40px] border border-dashed border-white/10">
                      <p className="text-white/20 font-black uppercase tracking-widest">Không tìm thấy rạp phù hợp với lựa chọn của bạn.</p>
                    </div>
                  )}
                </div>
              </div>
              <div>
                <h3 className="text-2xl font-black uppercase italic tracking-tight mb-8 flex items-center gap-3">
                  <div className="w-2 h-8 bg-secondary rounded-full" />
                  Chọn Suất Chiếu
                </h3>
                <div className="flex flex-wrap gap-5">
                  {['14:30', '16:45', '19:30', '21:15', '23:30'].map(time => (
                    <button 
                      key={time}
                      onClick={() => setSelectedTime(time)}
                      className={cn(
                        "px-10 py-5 rounded-2xl border font-black transition-all text-sm uppercase tracking-widest shadow-lg",
                        selectedTime === time ? "bg-primary text-white border-primary shadow-primary/20" : "bg-white/5 border-white/10 hover:border-white/30"
                      )}
                    >
                      {time}
                    </button>
                  ))}
                </div>
              </div>
            </div>
          )}

          {step === 2 && (
            <div className="flex flex-col items-center">
              <div className="w-full max-w-2xl h-3 bg-primary/20 rounded-full mb-16 relative shadow-[0_0_30px_rgba(139,92,246,0.1)]">
                <div className="absolute -top-10 left-1/2 -translate-x-1/2 text-[10px] font-black uppercase tracking-[0.3em] text-primary">Màn Hình</div>
                <div className="absolute inset-0 bg-primary/30 blur-md rounded-full" />
              </div>
              <div className="grid grid-cols-10 gap-4">
                {Array.from({ length: 80 }).map((_, i) => {
                  const id = `${String.fromCharCode(65 + Math.floor(i / 10))}${i % 10 + 1}`;
                  const isBooked = bookedSeats.includes(id) || [12, 13, 25, 26, 44, 45].includes(i);
                  const lock = lockedSeats[id];
                  const isLockedByOthers = lock && lock.userId !== socket.id;
                  const isSelected = selectedSeats.includes(id);
                  const type = getSeatType(id);
                  
                  return (
                    <button 
                      key={id}
                      disabled={isBooked || isLockedByOthers}
                      onClick={() => toggleSeat(id)}
                      className={cn(
                        "w-12 h-12 rounded-2xl flex flex-col items-center justify-center transition-all relative group",
                        isBooked ? "text-white/5 cursor-not-allowed" :
                        isLockedByOthers ? "text-secondary/50 cursor-not-allowed" :
                        isSelected ? "text-primary scale-110" : 
                        type === 'VIP' ? "text-accent/70 hover:text-primary" :
                        type === 'Sweetbox' ? "text-secondary/70 hover:text-primary" :
                        "text-white/40 hover:text-primary"
                      )}
                    >
                      <Armchair 
                        size={28} 
                        className={cn(
                          "transition-all",
                          isSelected && "fill-primary drop-shadow-[0_0_8px_rgba(139,92,246,0.5)]",
                          type === 'VIP' && !isSelected && "fill-accent/10",
                          type === 'Sweetbox' && !isSelected && "fill-secondary/10"
                        )} 
                      />
                      <span className={cn(
                        "text-[9px] font-black absolute -bottom-2",
                        isBooked ? "text-white/5" : isSelected ? "text-primary" : "text-white/20"
                      )}>
                        {id}
                      </span>
                      {isLockedByOthers && (
                        <div className="absolute -top-1 -right-1 w-2.5 h-2.5 bg-secondary rounded-full animate-pulse shadow-[0_0_10px_rgba(244,114,182,0.5)]" />
                      )}
                    </button>
                  );
                })}
              </div>
              <div className="mt-20 grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-8 text-[9px] font-black uppercase tracking-widest text-white/30">
                <div className="flex items-center gap-3"><Armchair size={18} className="text-white/40" /> Thường (95k)</div>
                <div className="flex items-center gap-3"><Armchair size={18} className="text-accent fill-accent/20" /> VIP (125k)</div>
                <div className="flex items-center gap-3"><Armchair size={18} className="text-secondary fill-secondary/20" /> Sweetbox (250k)</div>
                <div className="flex items-center gap-3"><Armchair size={18} className="text-primary fill-primary" /> Đang chọn</div>
                <div className="flex items-center gap-3"><Armchair size={18} className="text-white/5" /> Đã đặt</div>
                <div className="flex items-center gap-3"><div className="w-3.5 h-3.5 bg-secondary rounded-full shadow-[0_0_8px_rgba(244,114,182,0.5)]" /> Đang chọn</div>
              </div>
            </div>
          )}

          {step === 3 && (
            <div className="space-y-8">
              {MOCK_COMBOS.map(combo => {
                const selected = selectedCombos.find(c => c.id === combo.id);
                return (
                  <div key={combo.id} className="p-8 bg-white/5 rounded-[40px] border border-white/5 flex items-center gap-10 hover:border-primary/20 transition-all shadow-xl group">
                    <div className="w-32 h-32 rounded-3xl overflow-hidden shadow-2xl border border-white/10 group-hover:scale-105 transition-transform duration-500">
                      <img src={combo.image} className="w-full h-full object-cover" alt={combo.name} />
                    </div>
                    <div className="flex-1">
                      <h4 className="font-black text-2xl uppercase italic tracking-tight mb-2 group-hover:text-primary transition-colors">{combo.name}</h4>
                      <p className="text-sm text-white/40 mb-4 font-medium leading-relaxed">{combo.description}</p>
                      <p className="text-primary font-black text-xl tracking-tighter">{combo.price.toLocaleString()}đ</p>
                    </div>
                    <div className="flex items-center gap-6 bg-white/5 p-3 rounded-2xl border border-white/5">
                      <button 
                        onClick={() => {
                          if (!selected) return;
                          if (selected.qty === 1) setSelectedCombos(prev => prev.filter(c => c.id !== combo.id));
                          else setSelectedCombos(prev => prev.map(c => c.id === combo.id ? { ...c, qty: c.qty - 1 } : c));
                        }}
                        className="w-12 h-12 rounded-xl border border-white/10 flex items-center justify-center hover:bg-white/10 transition-all text-xl font-black"
                      >
                        -
                      </button>
                      <span className="font-black text-xl w-6 text-center">{selected?.qty || 0}</span>
                      <button 
                        onClick={() => {
                          if (!selected) setSelectedCombos(prev => [...prev, { ...combo, qty: 1 }]);
                          else setSelectedCombos(prev => prev.map(c => c.id === combo.id ? { ...c, qty: c.qty + 1 } : c));
                        }}
                        className="w-12 h-12 rounded-xl bg-primary text-white flex items-center justify-center hover:scale-105 transition-all text-xl font-black shadow-lg shadow-primary/20"
                      >
                        +
                      </button>
                    </div>
                  </div>
                );
              })}
            </div>
          )}

          {step === 4 && (
            <div className="space-y-10">
              <div className="p-8 bg-secondary/10 border border-secondary/20 rounded-[32px] flex items-center justify-between shadow-2xl shadow-secondary/5">
                <div className="flex items-center gap-4">
                  <Clock size={24} className="text-secondary" />
                  <span className="font-black text-secondary uppercase tracking-[0.2em] text-xs">Thời gian thanh toán còn lại</span>
                </div>
                <div className="text-3xl font-black font-mono text-secondary tracking-tighter">{formatTime(timeLeft)}</div>
              </div>

              <div className="p-10 bg-white/5 rounded-[40px] border border-white/5 shadow-2xl">
                <h3 className="text-2xl font-black mb-10 flex items-center gap-4 uppercase italic tracking-tight">
                  <CreditCard size={28} className="text-primary" /> 
                  Thanh toán 100% giá trị vé
                </h3>
                <div className="grid gap-5">
                  {['Chuyển khoản qua QR', 'Ví MoMo', 'Thẻ ATM / Internet Banking', 'Thẻ Visa / Mastercard', 'ShopeePay'].map(method => (
                    <label 
                      key={method} 
                      className={cn(
                        "flex items-center justify-between p-6 rounded-[24px] border cursor-pointer transition-all group",
                        paymentMethod === method ? "bg-primary/10 border-primary shadow-lg shadow-primary/5" : "bg-white/5 border-white/5 hover:border-white/20"
                      )}
                      onClick={() => setPaymentMethod(method)}
                    >
                      <div className="flex items-center gap-5">
                        <div className={cn(
                          "w-6 h-6 rounded-full border-2 flex items-center justify-center transition-all",
                          paymentMethod === method ? "border-primary" : "border-white/20"
                        )}>
                          {paymentMethod === method && <div className="w-3 h-3 rounded-full bg-primary shadow-[0_0_8px_rgba(139,92,246,0.5)]" />}
                        </div>
                        <span className="font-black uppercase tracking-widest text-sm group-hover:text-primary transition-colors">{method}</span>
                      </div>
                    </label>
                  ))}
                </div>

                <motion.div 
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  className="mt-12 p-10 bg-bg-dark/60 rounded-[40px] border border-primary/20 flex flex-col md:flex-row items-center gap-12 relative overflow-hidden"
                >
                  <div className="absolute inset-0 bg-primary/5 blur-[100px] -z-10" />
                  <div className="w-56 h-56 bg-white p-3 rounded-[32px] shadow-2xl border-4 border-white/10">
                    <img 
                      src={`https://api.qrserver.com/v1/create-qr-code/?size=200x200&data=vietcombank|1032059504|NGUYEN VIET TIEN|${totalPrice}`} 
                      className="w-full h-full rounded-2xl" 
                      alt="QR Code Payment" 
                    />
                  </div>
                  <div className="flex-1 space-y-6 text-center md:text-left">
                    <div className="grid grid-cols-2 gap-8">
                      <div>
                        <p className="text-[10px] font-black uppercase tracking-widest text-white/20 mb-2">Ngân hàng</p>
                        <p className="font-black text-primary uppercase italic">VIETCOMBANK (VCB)</p>
                      </div>
                      <div>
                        <p className="text-[10px] font-black uppercase tracking-widest text-white/20 mb-2">Số tài khoản</p>
                        <p className="text-2xl font-black tracking-tighter">1032059504</p>
                      </div>
                      <div>
                        <p className="text-[10px] font-black uppercase tracking-widest text-white/20 mb-2">Chủ tài khoản</p>
                        <p className="font-black uppercase italic">NGUYEN VIET TIEN</p>
                      </div>
                      <div>
                        <p className="text-[10px] font-black uppercase tracking-widest text-white/20 mb-2">Chi nhánh</p>
                        <p className="text-sm font-bold">Trụ sở CN Thành Công</p>
                      </div>
                    </div>
                    <div className="pt-6 border-t border-white/5 space-y-2">
                      <p className="text-[10px] text-white/30 font-bold italic">* Vui lòng thanh toán 100% số tiền: <span className="text-white font-black">{totalPrice.toLocaleString()}đ</span></p>
                      <p className="text-[10px] text-white/30 font-bold italic">* Nội dung chuyển khoản: <span className="text-white font-black">CM_{Math.random().toString(36).substring(7).toUpperCase()}</span></p>
                    </div>
                  </div>
                </motion.div>
              </div>
              <div className="p-10 bg-primary/5 rounded-[40px] border border-primary/20 shadow-2xl">
                <div className="flex flex-col md:flex-row items-center gap-8">
                  <div className="flex items-center gap-5 flex-1">
                    <div className="p-4 bg-primary/20 rounded-2xl">
                      <Gift size={28} className="text-primary" />
                    </div>
                    <div className="flex-1">
                      <p className="font-black uppercase italic tracking-tight text-lg">Mã giảm giá</p>
                      <p className="text-sm text-white/40 font-medium">Nhập mã <span className="text-primary font-black">VTIX10</span> để giảm 10%</p>
                    </div>
                  </div>
                  <div className="flex items-center gap-3 w-full md:w-auto">
                    <input 
                      type="text" 
                      placeholder="Nhập mã..." 
                      value={couponCode}
                      onChange={(e) => setCouponCode(e.target.value)}
                      className="bg-white/5 border border-white/10 rounded-2xl px-6 py-4 text-sm font-bold focus:outline-none focus:border-primary flex-1 md:w-48" 
                    />
                    <button 
                      onClick={() => {
                        if (couponCode.toUpperCase() === 'VTIX10') {
                          setIsCouponApplied(true);
                          alert('Áp dụng mã giảm giá thành công!');
                        } else {
                          alert('Mã giảm giá không hợp lệ!');
                        }
                      }}
                      className="px-8 py-4 bg-primary text-white font-black rounded-2xl text-xs uppercase tracking-widest hover:scale-105 transition-all shadow-lg shadow-primary/20"
                    >
                      Áp dụng
                    </button>
                  </div>
                </div>
              </div>
            </div>
          )}
        </div>

        {/* Summary Sidebar */}
        <div className="lg:col-span-1">
          <div className="sticky top-32 p-10 bg-white/5 rounded-[40px] border border-white/10 shadow-2xl backdrop-blur-xl">
            <h3 className="text-xl font-black uppercase italic tracking-tight mb-10 pb-6 border-b border-white/5">Thông tin đặt vé</h3>
            <div className="space-y-6 mb-10">
              <div className="flex justify-between items-start gap-4">
                <span className="text-[10px] font-black uppercase tracking-widest text-white/20 mt-1">Phim</span>
                <span className="font-black text-right uppercase italic tracking-tight leading-tight">{movie.title}</span>
              </div>
              <div className="flex justify-between items-start gap-4">
                <span className="text-[10px] font-black uppercase tracking-widest text-white/20 mt-1">Rạp</span>
                <span className="font-black text-right uppercase italic tracking-tight leading-tight">{selectedTheater.name}</span>
              </div>
              <div className="flex justify-between items-start gap-4">
                <span className="text-[10px] font-black uppercase tracking-widest text-white/20 mt-1">Suất chiếu</span>
                <span className="font-black text-right uppercase italic tracking-tight leading-tight">{selectedTime} • Hôm nay</span>
              </div>
              {selectedSeats.length > 0 && (
                <div className="flex justify-between items-start gap-4">
                  <span className="text-[10px] font-black uppercase tracking-widest text-white/20 mt-1">Ghế ({selectedSeats.length})</span>
                  <span className="font-black text-right text-primary uppercase italic tracking-tight leading-tight">{selectedSeats.join(', ')}</span>
                </div>
              )}
              {selectedCombos.length > 0 && (
                <div className="space-y-4 pt-4 border-t border-white/5">
                  <p className="text-[10px] font-black uppercase tracking-[0.2em] text-white/20">Bắp nước</p>
                  {selectedCombos.map(c => (
                    <div key={c.id} className="flex justify-between text-sm font-bold">
                      <span className="text-white/60">{c.name} x{c.qty}</span>
                      <span className="font-black">{(c.price * c.qty).toLocaleString()}đ</span>
                    </div>
                  ))}
                </div>
              )}
            </div>
            <div className="pt-8 border-t border-white/10 mb-10">
              <div className="flex justify-between items-end">
                <span className="text-[10px] font-black uppercase tracking-widest text-white/20 mb-2">Tổng cộng</span>
                <span className="text-4xl font-black text-primary tracking-tighter drop-shadow-[0_0_15px_rgba(139,92,246,0.3)]">{totalPrice.toLocaleString()}đ</span>
              </div>
            </div>
            <button 
              onClick={() => {
                if (step < 4) setStep(step + 1);
                else handleConfirm();
              }}
              disabled={step === 2 && selectedSeats.length === 0}
              className="w-full py-5 btn-gradient text-white font-black rounded-[24px] uppercase tracking-[0.2em] text-xs shadow-2xl hover:scale-[1.02] disabled:opacity-50 disabled:cursor-not-allowed disabled:hover:scale-100 transition-all"
            >
              {step === 4 ? 'Thanh Toán Ngay' : 'Tiếp Tục'}
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};

// --- Admin Views ---

const UserProfileView = ({ user, onBack }: { user: UserType, onBack: () => void }) => {
  const [activeTab, setActiveTab] = useState('history');

  return (
    <div className="min-h-screen bg-bg-dark text-white pt-32 pb-20 px-6">
      <div className="max-w-7xl mx-auto">
        <button 
          onClick={onBack} 
          className="mb-12 flex items-center gap-3 text-white/40 hover:text-primary transition-all font-black uppercase tracking-widest text-xs"
        >
          <ChevronLeft size={20} /> Quay lại
        </button>

        <div className="grid lg:grid-cols-3 gap-16">
          {/* Profile Sidebar */}
          <div className="lg:col-span-1">
            <div className="p-10 bg-white/5 rounded-[40px] border border-white/10 text-center sticky top-32 shadow-2xl backdrop-blur-xl">
              <div className="w-32 h-32 rounded-full bg-primary mx-auto mb-8 flex items-center justify-center text-4xl font-black text-white shadow-2xl shadow-primary/30 relative group">
                {user.name[0]}
                <div className="absolute inset-0 rounded-full bg-white/20 blur-xl opacity-0 group-hover:opacity-100 transition-opacity" />
              </div>
              <h2 className="text-3xl font-black mb-2 uppercase italic tracking-tight">{user.name}</h2>
              <p className="text-white/30 text-sm mb-10 font-medium">{user.email}</p>
              
              <div className="grid grid-cols-2 gap-5 mb-10">
                <div className="p-5 bg-bg-dark/60 rounded-3xl border border-white/5">
                  <p className="text-[10px] font-black uppercase tracking-widest text-white/20 mb-2">Hạng</p>
                  <p className="text-primary font-black text-lg uppercase italic tracking-tight">{user.tier}</p>
                </div>
                <div className="p-5 bg-bg-dark/60 rounded-3xl border border-white/5">
                  <p className="text-[10px] font-black uppercase tracking-widest text-white/20 mb-2">Điểm</p>
                  <p className="text-primary font-black text-lg tracking-tighter">{user.points}</p>
                </div>
              </div>

              <div className="space-y-3">
                {[
                  { id: 'profile', name: 'Thông tin cá nhân', icon: User },
                  { id: 'history', name: 'Lịch sử đặt vé', icon: History },
                  { id: 'promos', name: 'Ưu đãi của tôi', icon: Gift },
                  { id: 'settings', name: 'Cài đặt', icon: Settings }
                ].map(item => (
                  <button 
                    key={item.id} 
                    onClick={() => setActiveTab(item.id)}
                    className={cn(
                      "w-full py-4 px-8 rounded-2xl text-left text-xs font-black uppercase tracking-widest transition-all flex items-center justify-between group",
                      activeTab === item.id ? "bg-primary text-white shadow-lg shadow-primary/20" : "hover:bg-white/5 text-white/40 hover:text-white"
                    )}
                  >
                    <span className="flex items-center gap-4">
                      <item.icon size={18} /> {item.name}
                    </span>
                    <ChevronRight size={16} className={cn("transition-all", activeTab === item.id ? "translate-x-0 opacity-100" : "-translate-x-2 opacity-0 group-hover:translate-x-0 group-hover:opacity-100")} />
                  </button>
                ))}
              </div>
            </div>
          </div>

          {/* Content Area */}
          <div className="lg:col-span-2">
            {activeTab === 'history' && (
              <div className="space-y-8">
                <h3 className="text-4xl font-black mb-12 italic uppercase tracking-tighter flex items-center gap-4">
                  <div className="w-2 h-10 bg-primary rounded-full" />
                  Lịch sử đặt vé
                </h3>
                {[1, 2].map(i => (
                  <div key={i} className="p-10 bg-white/5 rounded-[40px] border border-white/5 hover:border-primary/30 transition-all group shadow-2xl">
                    <div className="flex flex-col md:flex-row gap-10">
                      <div className="w-full md:w-40 aspect-[2/3] rounded-[32px] overflow-hidden flex-shrink-0 shadow-2xl border border-white/10 group-hover:scale-105 transition-transform duration-500">
                        <img src={MOCK_MOVIES[i].image} className="w-full h-full object-cover" alt="Movie" />
                      </div>
                      <div className="flex-1">
                        <div className="flex justify-between items-start mb-8">
                          <div>
                            <span className="text-[10px] font-black uppercase tracking-[0.2em] text-primary mb-2 block">Mã vé: VTIX-9928{i}</span>
                            <h4 className="text-3xl font-black group-hover:text-primary transition-colors uppercase italic tracking-tight leading-tight">{MOCK_MOVIES[i].title}</h4>
                          </div>
                          <div className="px-5 py-2 bg-primary/10 text-primary border border-primary/20 rounded-full text-[10px] font-black uppercase tracking-widest shadow-sm">Đã thanh toán</div>
                        </div>
                        <div className="grid grid-cols-2 gap-8 mb-10">
                          <div>
                            <p className="text-[10px] font-black uppercase tracking-widest text-white/20 mb-2">Thời gian</p>
                            <p className="text-sm font-bold text-white/80">19:30 • 04/03/2024</p>
                          </div>
                          <div>
                            <p className="text-[10px] font-black uppercase tracking-widest text-white/20 mb-2">Rạp</p>
                            <p className="text-sm font-bold text-white/80">VTIX Landmark 81</p>
                          </div>
                          <div>
                            <p className="text-[10px] font-black uppercase tracking-widest text-white/20 mb-2">Ghế</p>
                            <p className="text-sm font-black text-primary uppercase italic">F12, F13</p>
                          </div>
                          <div>
                            <p className="text-[10px] font-black uppercase tracking-widest text-white/20 mb-2">Tổng tiền</p>
                            <p className="text-sm font-black text-white tracking-tighter">240.000đ</p>
                          </div>
                        </div>
                        <div className="flex gap-5">
                          <button className="flex-1 py-4 bg-white/5 hover:bg-white/10 rounded-2xl text-[10px] font-black uppercase tracking-widest transition-all flex items-center justify-center gap-3 border border-white/5">
                            <QrCode size={16} className="text-primary" /> Xem mã vé
                          </button>
                          <button className="flex-1 py-4 bg-white/5 hover:bg-white/10 rounded-2xl text-[10px] font-black uppercase tracking-widest transition-all flex items-center justify-center gap-3 border border-white/5">
                            <Info size={16} className="text-secondary" /> Chi tiết
                          </button>
                        </div>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            )}
            {activeTab !== 'history' && (
              <div className="p-32 text-center bg-white/5 rounded-[40px] border border-dashed border-white/10 shadow-2xl">
                <AlertCircle size={64} className="text-white/10 mx-auto mb-8" />
                <p className="text-white/20 font-black uppercase tracking-widest">Tính năng đang được phát triển.</p>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};

const AdminDashboard = () => {
  return (
    <div className="min-h-screen bg-bg-dark text-white pt-32 pb-20 px-10 font-sans">
      <div className="flex flex-col md:flex-row items-center justify-between mb-16 border-b border-white/10 pb-10 gap-8">
        <div>
          <h1 className="text-5xl font-black tracking-tighter mb-4 uppercase italic leading-tight">Bảng Điều Khiển Hệ Thống</h1>
          <p className="text-white/30 text-[10px] font-black uppercase tracking-[0.3em] flex items-center gap-3">
            <span className="w-2 h-2 bg-primary rounded-full animate-pulse" />
            Người vận hành: Admin_Root | Phiên làm việc: Đang hoạt động
          </p>
        </div>
        <div className="flex gap-5">
          <div className="px-6 py-3 bg-white/5 border border-white/10 rounded-2xl text-[10px] font-black uppercase tracking-widest flex items-center gap-3 shadow-xl">
            <div className="w-2 h-2 bg-primary rounded-full shadow-[0_0_8px_rgba(139,92,246,0.5)]" />
            Trạng thái: Tối ưu
          </div>
          <button className="px-8 py-3 bg-primary text-white rounded-2xl text-[10px] font-black uppercase tracking-[0.2em] shadow-2xl shadow-primary/20 hover:scale-105 transition-all">
            Xuất Báo Cáo
          </button>
        </div>
      </div>

      {/* Stats Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8 mb-16">
        {[
          { label: 'Doanh Thu Ngày', value: '42.5M', trend: '+12%', icon: TrendingUp, color: 'text-primary' },
          { label: 'Vé Đã Phát Hành', value: '1,240', trend: '+5%', icon: Ticket, color: 'text-secondary' },
          { label: 'Tỷ Lệ Lấp Đầy', value: '68%', trend: '+2%', icon: Layers, color: 'text-accent' },
          { label: 'Đăng Ký Mới', value: '85', trend: '+18%', icon: Users, color: 'text-primary' },
        ].map((stat, i) => (
          <div key={i} className="p-10 bg-white/5 border border-white/10 rounded-[40px] hover:bg-white/10 transition-all group shadow-2xl relative overflow-hidden">
            <div className="flex items-center justify-between mb-8 relative z-10">
              <div className={cn("p-4 rounded-2xl bg-white/5 border border-white/10 group-hover:scale-110 transition-transform", stat.color)}>
                <stat.icon size={24} />
              </div>
              <span className="text-[10px] font-black text-primary bg-primary/10 px-3 py-1.5 rounded-full border border-primary/20">{stat.trend}</span>
            </div>
            <p className="text-[10px] text-white/30 font-black uppercase tracking-[0.2em] mb-2 relative z-10">{stat.label}</p>
            <p className="text-4xl font-black tracking-tighter relative z-10">{stat.value}</p>
            <div className="absolute top-0 right-0 w-32 h-32 bg-primary/5 blur-[60px] rounded-full -mr-16 -mt-16 group-hover:bg-primary/10 transition-colors" />
          </div>
        ))}
      </div>

      <div className="grid lg:grid-cols-3 gap-16">
        <div className="lg:col-span-2 space-y-16">
          {/* Recent Bookings Table */}
          <div className="bg-white/5 border border-white/10 rounded-[40px] overflow-hidden shadow-2xl">
            <div className="p-8 bg-white/5 border-b border-white/10 flex items-center justify-between">
              <h3 className="text-[10px] font-black uppercase tracking-[0.3em] flex items-center gap-4">
                <div className="w-2 h-2 bg-primary rounded-full shadow-[0_0_8px_rgba(139,92,246,0.5)]" /> Giao Dịch Gần Đây
              </h3>
              <button className="text-[10px] text-white/30 hover:text-primary font-black uppercase tracking-widest transition-colors">Xem Nhật Ký</button>
            </div>
            <div className="overflow-x-auto">
              <table className="w-full text-left">
                <thead className="bg-bg-dark/60 text-[10px] font-black uppercase tracking-[0.2em] text-white/20 border-b border-white/5">
                  <tr>
                    <th className="px-8 py-6">Mã_Giao_Dịch</th>
                    <th className="px-8 py-6">Khách_Hàng</th>
                    <th className="px-8 py-6">Tên_Phim</th>
                    <th className="px-8 py-6">Giá_Trị</th>
                    <th className="px-8 py-6">Trạng_Thái</th>
                  </tr>
                </thead>
                <tbody className="text-xs font-bold divide-y divide-white/5">
                  {[
                    { id: 'TX-9281', user: 'NGUYEN_VAN_A', movie: 'DUNE_PART_TWO', amount: '285,000', status: 'THÀNH CÔNG' },
                    { id: 'TX-9280', user: 'TRAN_THI_B', movie: 'OPPENHEIMER', amount: '190,000', status: 'THÀNH CÔNG' },
                    { id: 'TX-9279', user: 'LE_VAN_C', movie: 'DUNE_PART_TWO', amount: '450,000', status: 'ĐANG CHỜ' },
                    { id: 'TX-9278', user: 'PHAM_MINH_D', movie: 'SPIDER_MAN_BEYOND', amount: '125,000', status: 'THÀNH CÔNG' },
                  ].map((row, i) => (
                    <tr key={i} className="hover:bg-white/5 transition-colors group">
                      <td className="px-8 py-6 text-white/30 font-mono">{row.id}</td>
                      <td className="px-8 py-6 font-black uppercase italic tracking-tight">{row.user}</td>
                      <td className="px-8 py-6 text-white/60">{row.movie}</td>
                      <td className="px-8 py-6 font-black text-primary tracking-tighter">{row.amount}</td>
                      <td className="px-8 py-6">
                        <span className={cn(
                          "px-4 py-1.5 rounded-full text-[9px] font-black uppercase tracking-widest border shadow-sm",
                          row.status === 'THÀNH CÔNG' ? "border-primary/30 text-primary bg-primary/5" : "border-secondary/30 text-secondary bg-secondary/5"
                        )}>
                          {row.status}
                        </span>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        </div>

        <div className="lg:col-span-1 space-y-16">
          {/* Top Movies List */}
          <div className="bg-white/5 border border-white/10 rounded-[40px] p-10 shadow-2xl">
            <h3 className="text-[10px] font-black uppercase tracking-[0.3em] mb-12 flex items-center gap-4">
              <div className="w-2 h-2 bg-secondary rounded-full shadow-[0_0_8px_rgba(244,114,182,0.5)]" /> Phim Hiệu Suất Cao
            </h3>
            <div className="space-y-10">
              {MOCK_MOVIES.slice(0, 3).map((movie, i) => (
                <div key={movie.id} className="group">
                  <div className="flex items-center justify-between mb-4">
                    <p className="text-xs font-black uppercase italic tracking-tight group-hover:text-primary transition-colors leading-tight">{movie.title}</p>
                    <p className="text-[10px] font-black text-white/20 tracking-widest">{(1200 - i * 300)} UNITS</p>
                  </div>
                  <div className="w-full bg-white/5 h-1.5 rounded-full overflow-hidden border border-white/5">
                    <motion.div 
                      initial={{ width: 0 }}
                      animate={{ width: `${90 - i * 15}%` }}
                      className="bg-primary h-full shadow-[0_0_10px_rgba(139,92,246,0.5)]" 
                    />
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Quick Actions */}
          <div className="bg-white/5 border border-white/10 rounded-[40px] p-10 shadow-2xl">
            <h3 className="text-[10px] font-black uppercase tracking-[0.3em] mb-12 flex items-center gap-4">
              <div className="w-2 h-2 bg-accent rounded-full shadow-[0_0_8px_rgba(34,211,238,0.5)]" /> Lệnh Hệ Thống
            </h3>
            <div className="grid grid-cols-2 gap-4">
              {[
                { label: 'THÊM_PHIM', icon: Film, color: 'text-primary' },
                { label: 'LỊCH_CHIẾU', icon: Calendar, color: 'text-secondary' },
                { label: 'SOÁT_VÉ', icon: QrCode, color: 'text-accent' },
                { label: 'CÀI_ĐẶT', icon: Settings, color: 'text-white/40' },
              ].map((action, i) => (
                <button key={i} className="p-6 bg-white/5 border border-white/5 hover:border-primary/30 rounded-3xl hover:bg-white/10 transition-all flex flex-col items-center gap-4 group shadow-lg">
                  <div className={cn("p-3 rounded-xl bg-white/5 border border-white/5 group-hover:scale-110 transition-transform", action.color)}>
                    <action.icon size={20} />
                  </div>
                  <span className="text-[9px] font-black tracking-[0.2em] uppercase">{action.label}</span>
                </button>
              ))}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

const Footer = () => {
  return (
    <footer className="bg-bg-dark border-t border-white/10 pt-24 pb-12 px-10">
      <div className="max-w-7xl mx-auto">
        {/* Cinema Formats */}
        <div className="flex flex-wrap justify-center gap-x-10 gap-y-6 mb-20 pb-16 border-b border-white/5">
          {['4DX', 'Imax', 'Starium', 'Goldclass', "L'amour", 'Sweetbox', 'Premium Cinema', 'Screenx', 'Cine & Foret', 'Cine & Living Room', 'Cine Suite'].map(format => (
            <span key={format} className="text-[10px] font-black tracking-[0.3em] text-white/20 hover:text-primary transition-all cursor-default uppercase italic">{format}</span>
          ))}
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-16 mb-20">
          {/* VTIX Việt Nam */}
          <div>
            <h4 className="text-xs font-black uppercase tracking-[0.2em] mb-8 text-white italic">VTIX Việt Nam</h4>
            <ul className="space-y-4">
              {['Giới Thiệu', 'Tiện Ích Online', 'Thẻ Quà Tặng', 'Tuyển Dụng', 'Liên Hệ Quảng Cáo VTIX', 'Dành cho đối tác'].map(item => (
                <li key={item}><a href="#" className="text-sm text-white/30 hover:text-primary transition-all font-medium">{item}</a></li>
              ))}
            </ul>
          </div>

          {/* Điều khoản sử dụng */}
          <div>
            <h4 className="text-xs font-black uppercase tracking-[0.2em] mb-8 text-white italic">Điều khoản sử dụng</h4>
            <ul className="space-y-4">
              {['Điều Khoản Chung', 'Điều Khoản Giao Dịch', 'Chính Sách Thanh Toán', 'Chính Sách Bảo Mật', 'Những Quy Định Tại Rạp Phim', 'Câu Hỏi Thường Gặp'].map(item => (
                <li key={item}><a href="#" className="text-sm text-white/30 hover:text-primary transition-all font-medium">{item}</a></li>
              ))}
            </ul>
          </div>

          {/* Kết nối với chúng tôi */}
          <div>
            <h4 className="text-xs font-black uppercase tracking-[0.2em] mb-8 text-white italic">Kết nối với chúng tôi</h4>
            <div className="flex gap-5 mb-10">
              <a href="https://www.facebook.com/viet.tien.538143?locale=vi_VN" target="_blank" rel="noopener noreferrer" className="w-12 h-12 rounded-2xl bg-white/5 border border-white/10 flex items-center justify-center hover:bg-primary hover:text-white transition-all shadow-lg group">
                <Facebook size={20} className="group-hover:scale-110 transition-transform" />
              </a>
              <a href="https://www.instagram.com/v.tien.ng?igsh=MXg0a3pqZ2twb3BjcA%3D%3D&utm_source=qr" target="_blank" rel="noopener noreferrer" className="w-12 h-12 rounded-2xl bg-white/5 border border-white/10 flex items-center justify-center hover:bg-primary hover:text-white transition-all shadow-lg group">
                <Instagram size={20} className="group-hover:scale-110 transition-transform" />
              </a>
            </div>
            <div className="w-40 h-16 bg-primary rounded-2xl flex items-center justify-center shadow-2xl shadow-primary/20 group cursor-pointer overflow-hidden relative">
              <div className="absolute inset-0 bg-white/10 translate-y-full group-hover:translate-y-0 transition-transform duration-500" />
              <span className="text-white font-black tracking-tighter text-3xl italic relative z-10">VTIX</span>
            </div>
          </div>

          {/* Chăm sóc khách hàng */}
          <div>
            <h4 className="text-xs font-black uppercase tracking-[0.2em] mb-8 text-white italic">Chăm sóc khách hàng</h4>
            <div className="space-y-6">
              <div className="p-5 bg-white/5 rounded-3xl border border-white/5">
                <p className="text-[10px] font-black uppercase tracking-widest text-white/20 mb-1">Hotline</p>
                <p className="text-xl font-black text-primary tracking-tighter">+84 979 456 479</p>
              </div>
              <div className="p-5 bg-white/5 rounded-3xl border border-white/5">
                <p className="text-[10px] font-black uppercase tracking-widest text-white/20 mb-1">Giờ làm việc</p>
                <p className="text-sm font-bold text-white/60">8:00 - 22:00 (Tất cả các ngày bao gồm cả Lễ Tết)</p>
              </div>
            </div>
          </div>
        </div>

        {/* Company Info */}
        <div className="pt-12 border-t border-white/5 flex flex-col lg:flex-row justify-between gap-8">
          <div className="max-w-3xl">
            <h5 className="text-sm font-black mb-4 text-white uppercase tracking-widest italic">CÔNG TY TNHH VTIX VIỆT NAM</h5>
            <div className="space-y-2 text-[10px] font-bold text-white/20 leading-relaxed uppercase tracking-widest">
              <p>Giấy Chứng nhận đăng ký doanh nghiệp: 083862004 đăng ký lần đầu ngày 04/11/2004, được cấp bởi Sở Kế hoạch và Đầu tư Thành phố Hà Nội</p>
              <p>Địa chỉ: Lầu 2, số 7/28, đường Thành Thái, Quận Cầu giấy , Thành phố Hà Nội, Việt Nam</p>
              <p>Đường dây nóng (Hotline): 0979 456 479</p>
              <p className="mt-4 text-white/40">COPYRIGHT 2017 VTIX VIETNAM CO., LTD. ALL RIGHTS RESERVED</p>
            </div>
          </div>
          <div className="flex gap-8 items-center">
            <img src="https://picsum.photos/seed/visa/40/25" className="h-6 opacity-20 hover:opacity-100 transition-opacity grayscale hover:grayscale-0" alt="Visa" referrerPolicy="no-referrer" />
            <img src="https://picsum.photos/seed/mastercard/40/25" className="h-6 opacity-20 hover:opacity-100 transition-opacity grayscale hover:grayscale-0" alt="Mastercard" referrerPolicy="no-referrer" />
            <img src="https://picsum.photos/seed/momo/40/25" className="h-6 opacity-20 hover:opacity-100 transition-opacity grayscale hover:grayscale-0" alt="Momo" referrerPolicy="no-referrer" />
          </div>
        </div>
      </div>
    </footer>
  );
};

// --- Main App Component ---

export default function App() {
  const [activeTab, setActiveTab] = useState('home');
  const [selectedMovie, setSelectedMovie] = useState<Movie | null>(null);
  const [user, setUser] = useState<UserType | null>(null);
  const [isAdminView, setIsAdminView] = useState(false);
  const [loginEmail, setLoginEmail] = useState('');
  const [loginPassword, setLoginPassword] = useState('');
  const [registeredUsers, setRegisteredUsers] = useState<any[]>([]);
  const [lastBookingCode, setLastBookingCode] = useState('');
  
  // Registration form state
  const [regName, setRegName] = useState('');
  const [regEmail, setRegEmail] = useState('');
  const [regPassword, setRegPassword] = useState('');

  // Mock Login
  const handleLogin = () => {
    if (loginEmail === 'Admin' && loginPassword === '0411') {
      setUser({
        id: 'admin',
        name: 'Quản Trị Viên',
        email: 'admin@vtix.com',
        role: 'admin',
        tier: 'Diamond',
        points: 9999
      });
      setIsAdminView(true);
      setActiveTab('home');
      setLoginEmail('');
      setLoginPassword('');
      return;
    }

    const foundUser = registeredUsers.find(u => u.email === loginEmail && u.password === loginPassword);
    
    if (foundUser) {
      setUser({
        id: foundUser.id,
        name: foundUser.name,
        email: foundUser.email,
        role: 'user',
        tier: 'Bronze',
        points: 0
      });
      setActiveTab('home');
      setLoginEmail('');
      setLoginPassword('');
    } else {
      alert('Tài khoản hoặc mật khẩu không chính xác. Bạn cần đăng ký trước khi đăng nhập.');
    }
  };

  const handleRegister = () => {
    if (!regName || !regEmail || !regPassword) {
      alert('Vui lòng điền đầy đủ thông tin.');
      return;
    }

    if (registeredUsers.find(u => u.email === regEmail)) {
      alert('Email này đã được đăng ký.');
      return;
    }

    const newUser = {
      id: 'u' + (registeredUsers.length + 1),
      name: regName,
      email: regEmail,
      password: regPassword
    };

    setRegisteredUsers([...registeredUsers, newUser]);
    alert('Đăng ký thành công! Bây giờ bạn có thể đăng nhập.');
    setActiveTab('login');
    setRegName('');
    setRegEmail('');
    setRegPassword('');
  };

  const handleLogout = () => {
    setUser(null);
    setIsAdminView(false);
    setActiveTab('home');
  };

  return (
    <div className="bg-bg-dark min-h-screen font-sans selection:bg-primary selection:text-white">
      <Navbar 
        activeTab={activeTab} 
        setActiveTab={setActiveTab} 
        user={user} 
        onLogout={handleLogout}
        isAdminView={isAdminView}
      />

      <AnimatePresence mode="wait">
        {isAdminView ? (
          <motion.div
            key="admin"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
          >
            <AdminDashboard />
          </motion.div>
        ) : (
          <motion.div
            key={activeTab + (selectedMovie?.id || '')}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -20 }}
            transition={{ duration: 0.4 }}
          >
            {activeTab === 'home' && (
              <HomeView onSelectMovie={(m) => {
                setSelectedMovie(m);
                setActiveTab('detail');
              }} />
            )}

            {activeTab === 'movies' && (
              <MoviesView onSelectMovie={(m) => {
                setSelectedMovie(m);
                setActiveTab('detail');
              }} />
            )}

            {activeTab === 'showtimes' && (
              <ShowtimesView onSelectMovie={(m) => {
                setSelectedMovie(m);
                setActiveTab('detail');
              }} />
            )}

            {activeTab === 'promotions' && (
              <PromotionsView />
            )}

            {activeTab === 'detail' && selectedMovie && (
              <MovieDetailView 
                movie={selectedMovie} 
                onBack={() => setActiveTab('home')} 
                onBook={() => {
                  if (!user) setActiveTab('login');
                  else setActiveTab('booking');
                }}
              />
            )}

            {activeTab === 'booking' && selectedMovie && (
              <BookingFlow 
                movie={selectedMovie} 
                user={user}
                onComplete={(code, data) => {
                  setLastBookingCode(code);
                  // Optionally update user history here
                  setActiveTab('success');
                }} 
                onCancel={() => {
                  alert('Hết thời gian thanh toán. Yêu cầu của bạn đã bị hủy.');
                  setActiveTab('home');
                }}
              />
            )}

            {activeTab === 'success' && (
              <div className="min-h-screen flex flex-col items-center justify-center text-center px-6 bg-bg-dark">
                <div className="w-32 h-32 bg-primary rounded-full flex items-center justify-center mb-10 shadow-2xl shadow-primary/30 relative group">
                  <QrCode size={56} className="text-white relative z-10" />
                  <div className="absolute inset-0 rounded-full bg-white/20 blur-2xl opacity-0 group-hover:opacity-100 transition-opacity" />
                </div>
                <h1 className="text-5xl font-black mb-6 uppercase italic tracking-tighter">Đặt Vé Thành Công!</h1>
                <div className="p-10 bg-white/5 rounded-[40px] border border-white/10 mb-12 w-full max-w-md shadow-2xl backdrop-blur-xl">
                  <p className="text-white/30 text-[10px] font-black uppercase tracking-[0.3em] mb-4">Mã đặt chỗ của bạn</p>
                  <p className="text-5xl font-black text-primary tracking-tighter uppercase italic">{lastBookingCode}</p>
                </div>
                <p className="text-white/40 mb-16 max-w-md font-medium leading-relaxed">Cảm ơn bạn đã tin tưởng VTIX. Mã vé đã được gửi về email và lưu trong mục vé của tôi.</p>
                <div className="flex flex-col sm:flex-row gap-5">
                  <button onClick={() => setActiveTab('home')} className="px-10 py-5 bg-white text-black font-black rounded-2xl uppercase tracking-widest text-xs hover:scale-105 transition-all shadow-xl">Về Trang Chủ</button>
                  <button onClick={() => setActiveTab('profile')} className="px-10 py-5 bg-white/5 border border-white/10 text-white font-black rounded-2xl uppercase tracking-widest text-xs hover:bg-white/10 transition-all shadow-xl">Xem Vé Của Tôi</button>
                </div>
              </div>
            )}

            {activeTab === 'profile' && user && (
              <UserProfileView 
                user={user} 
                onBack={() => setActiveTab('home')} 
              />
            )}

            {activeTab === 'login' && (
              <div className="min-h-screen flex items-center justify-center px-6 bg-bg-dark">
                <div className="w-full max-w-md p-12 bg-white/5 rounded-[40px] border border-white/10 shadow-2xl backdrop-blur-xl">
                  <div className="text-center mb-12">
                    <div className="w-20 h-20 bg-primary rounded-3xl flex items-center justify-center mx-auto mb-8 shadow-2xl shadow-primary/20 group">
                      <Film size={40} className="text-white group-hover:scale-110 transition-transform" />
                    </div>
                    <h2 className="text-4xl font-black mb-3 uppercase italic tracking-tight">Chào mừng trở lại</h2>
                    <p className="text-white/30 font-medium">Đăng nhập để trải nghiệm VTIX</p>
                  </div>
                  <div className="space-y-5">
                    <div className="relative">
                      <input 
                        type="text" 
                        placeholder="Email hoặc Tên đăng nhập" 
                        value={loginEmail}
                        onChange={(e) => setLoginEmail(e.target.value)}
                        className="w-full px-8 py-5 bg-bg-dark/60 border border-white/10 rounded-2xl focus:outline-none focus:border-primary transition-all text-white placeholder:text-white/20 font-bold" 
                      />
                    </div>
                    <div className="relative">
                      <input 
                        type="password" 
                        placeholder="Mật khẩu" 
                        value={loginPassword}
                        onChange={(e) => setLoginPassword(e.target.value)}
                        className="w-full px-8 py-5 bg-bg-dark/60 border border-white/10 rounded-2xl focus:outline-none focus:border-primary transition-all text-white placeholder:text-white/20 font-bold" 
                      />
                    </div>
                    <button 
                      onClick={handleLogin}
                      className="w-full py-5 btn-gradient text-white font-black rounded-2xl uppercase tracking-[0.2em] text-xs shadow-2xl hover:scale-[1.02] transition-all mt-6"
                    >
                      Đăng Nhập
                    </button>
                    <div className="text-center mt-6">
                      <button onClick={() => setActiveTab('register')} className="text-xs font-black uppercase tracking-widest text-white/30 hover:text-primary transition-colors">Chưa có tài khoản? Đăng ký ngay</button>
                    </div>
                    <div className="relative py-6">
                      <div className="absolute inset-0 flex items-center"><div className="w-full border-t border-white/5"></div></div>
                      <div className="relative flex justify-center text-[10px] font-black uppercase tracking-widest"><span className="bg-bg-dark px-4 text-white/20">Hoặc tiếp tục với</span></div>
                    </div>
                    <div className="grid grid-cols-2 gap-5">
                      <button className="py-4 bg-white/5 border border-white/10 rounded-2xl hover:bg-white/10 transition-all text-[10px] font-black uppercase tracking-widest">Google</button>
                      <button className="py-4 bg-white/5 border border-white/10 rounded-2xl hover:bg-white/10 transition-all text-[10px] font-black uppercase tracking-widest">Facebook</button>
                    </div>
                  </div>
                </div>
              </div>
            )}

            {activeTab === 'register' && (
              <div className="min-h-screen flex items-center justify-center px-6 bg-bg-dark">
                <div className="w-full max-w-md p-12 bg-white/5 rounded-[40px] border border-white/10 shadow-2xl backdrop-blur-xl">
                  <div className="text-center mb-12">
                    <div className="w-20 h-20 bg-primary rounded-3xl flex items-center justify-center mx-auto mb-8 shadow-2xl shadow-primary/20 group">
                      <Film size={40} className="text-white group-hover:scale-110 transition-transform" />
                    </div>
                    <h2 className="text-4xl font-black mb-3 uppercase italic tracking-tight">Tạo tài khoản mới</h2>
                    <p className="text-white/30 font-medium">Tham gia VTIX để nhận nhiều ưu đãi</p>
                  </div>
                  <div className="space-y-5">
                    <input 
                      type="text" 
                      placeholder="Họ và tên" 
                      value={regName}
                      onChange={(e) => setRegName(e.target.value)}
                      className="w-full px-8 py-5 bg-bg-dark/60 border border-white/10 rounded-2xl focus:outline-none focus:border-primary transition-all text-white placeholder:text-white/20 font-bold" 
                    />
                    <input 
                      type="email" 
                      placeholder="Email" 
                      value={regEmail}
                      onChange={(e) => setRegEmail(e.target.value)}
                      className="w-full px-8 py-5 bg-bg-dark/60 border border-white/10 rounded-2xl focus:outline-none focus:border-primary transition-all text-white placeholder:text-white/20 font-bold" 
                    />
                    <input 
                      type="password" 
                      placeholder="Mật khẩu" 
                      value={regPassword}
                      onChange={(e) => setRegPassword(e.target.value)}
                      className="w-full px-8 py-5 bg-bg-dark/60 border border-white/10 rounded-2xl focus:outline-none focus:border-primary transition-all text-white placeholder:text-white/20 font-bold" 
                    />
                    <input type="password" placeholder="Xác nhận mật khẩu" className="w-full px-8 py-5 bg-bg-dark/60 border border-white/10 rounded-2xl focus:outline-none focus:border-primary transition-all text-white placeholder:text-white/20 font-bold" />
                    <button 
                      onClick={handleRegister}
                      className="w-full py-5 btn-gradient text-white font-black rounded-2xl uppercase tracking-[0.2em] text-xs shadow-2xl hover:scale-[1.02] transition-all mt-6"
                    >
                      Đăng Ký
                    </button>
                    <div className="text-center mt-6">
                      <button onClick={() => setActiveTab('login')} className="text-xs font-black uppercase tracking-widest text-white/30 hover:text-primary transition-colors">Đã có tài khoản? Đăng nhập</button>
                    </div>
                  </div>
                </div>
              </div>
            )}
          </motion.div>
        )}
      </AnimatePresence>

      {/* Floating Admin Toggle for Demo */}
      <button 
        onClick={() => setIsAdminView(!isAdminView)}
        className="fixed bottom-6 right-6 w-14 h-14 bg-zinc-900 border border-white/10 rounded-full flex items-center justify-center text-white/40 hover:text-emerald-500 hover:border-emerald-500/50 transition-all z-[60] shadow-2xl"
      >
        {isAdminView ? <Users size={24} /> : <LayoutDashboard size={24} />}
      </button>

      <Chatbot />
      <Footer />
    </div>
  );
}
