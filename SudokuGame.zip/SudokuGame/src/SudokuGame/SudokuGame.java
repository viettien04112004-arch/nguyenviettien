import javax.swing.*;
import java.awt.*;

public class SudokuGame extends JFrame {

    private JTextField[][] cells = new JTextField[9][9];
    private int[][] fixedBoard = {
        {5,3,0, 0,7,0, 0,0,0},
        {6,0,0, 1,9,5, 0,0,0},
        {0,9,8, 0,0,0, 0,6,0},
        {8,0,0, 0,6,0, 0,0,3},
        {4,0,0, 8,0,3, 0,0,1},
        {7,0,0, 0,2,0, 0,0,6},
        {0,6,0, 0,0,0, 2,8,0},
        {0,0,0, 4,1,9, 0,0,5},
        {0,0,0, 0,8,0, 0,7,9}
    };

    public SudokuGame() {
        setTitle("Sudoku Game - Java Swing");
        setSize(600, 600);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setLayout(null);

        JPanel grid = new JPanel(new GridLayout(9, 9));
        grid.setBounds(20, 20, 450, 450);
        add(grid);

        for (int i = 0; i < 9; i++) {
            for (int j = 0; j < 9; j++) {
                JTextField txt = new JTextField();
                txt.setHorizontalAlignment(JTextField.CENTER);
                txt.setFont(new Font("Arial", Font.BOLD, 18));
                if (fixedBoard[i][j] != 0) {
                    txt.setText(String.valueOf(fixedBoard[i][j]));
                    txt.setEnabled(false);
                    txt.setBackground(Color.LIGHT_GRAY);
                }
                cells[i][j] = txt;
                grid.add(txt);
            }
        }

        JButton btnCheck = new JButton("Kiểm tra");
        btnCheck.setBounds(480, 50, 100, 40);
        add(btnCheck);

        JButton btnReset = new JButton("Chơi lại");
        btnReset.setBounds(480, 110, 100, 40);
        add(btnReset);

        btnCheck.addActionListener(e -> {
            for (int i = 0; i < 9; i++) {
                for (int j = 0; j < 9; j++) {
                    String val = cells[i][j].getText();
                    if (val.isEmpty()) {
                        JOptionPane.showMessageDialog(this, "Ô (" + (i+1) + "," + (j+1) + ") đang trống.");
                        return;
                    }
                    try {
                        int n = Integer.parseInt(val);
                        if (n < 1 || n > 9) throw new Exception();
                    } catch (Exception ex) {
                        JOptionPane.showMessageDialog(this, "Ô (" + (i+1) + "," + (j+1) + ") không hợp lệ.");
                        return;
                    }
                }
            }
            JOptionPane.showMessageDialog(this, "Tất cả ô hợp lệ (chưa kiểm tra trùng số)!");
        });

        btnReset.addActionListener(e -> {
            for (int i = 0; i < 9; i++) {
                for (int j = 0; j < 9; j++) {
                    if (fixedBoard[i][j] == 0) {
                        cells[i][j].setText("");
                        cells[i][j].setEnabled(true);
                        cells[i][j].setBackground(Color.WHITE);
                    }
                }
            }
        });
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            new SudokuGame().setVisible(true);
        });
    }
}